"""A minimal in-process rate limiter for sensitive endpoints (login, password reset,
resend verification). Good enough for a single backend instance; if you scale to
multiple instances, swap `_buckets` for a Redis-backed counter (same interface).
"""
import time
from collections import defaultdict

from fastapi import HTTPException, status

_buckets: dict[str, list[float]] = defaultdict(list)


def rate_limit(key: str, max_calls: int, window_seconds: int) -> None:
    now = time.monotonic()
    bucket = _buckets[key]
    cutoff = now - window_seconds
    while bucket and bucket[0] < cutoff:
        bucket.pop(0)
    if len(bucket) >= max_calls:
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, "Too many attempts. Please try again later.")
    bucket.append(now)
