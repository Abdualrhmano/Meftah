import json
from decimal import Decimal
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from .. import storage
from ..database import get_db
from ..deps import require_role
from ..models import Property, PropertyMedia, User
from ..schemas import (
    PropertyCreate,
    PropertyListOut,
    PropertyOut,
    PropertyStatusIn,
    PropertyUpdate,
    PropertyType,
    RentalPeriod,
    Scope,
    TransactionType,
)

router = APIRouter(prefix="/api/properties", tags=["properties"])
owner_only = require_role("owner")


async def _load(db: AsyncSession, property_id: int) -> Property | None:
    result = await db.execute(
        select(Property).where(Property.id == property_id).execution_options(populate_existing=True)
    )
    return result.scalar_one_or_none()


async def _load_owned(db: AsyncSession, property_id: int, user: User) -> Property:
    prop = await _load(db, property_id)
    if prop is None or prop.owner_id != user.id:
        # Same answer for "missing" and "not yours" so ids can't be probed.
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Property not found")
    return prop


def _set_media(prop: Property, media_in) -> None:
    for item in media_in:
        if not storage.is_own_url(item.url):
            raise HTTPException(422, "Media must be uploaded through the platform upload endpoint")
    prop.media.clear()
    prop.media.extend(
        PropertyMedia(url=item.url, media_type=item.media_type, sort_order=index)
        for index, item in enumerate(media_in)
    )


def _fields(data: PropertyCreate) -> dict:
    fields = data.model_dump(exclude={"media"})
    fields["price"] = Decimal(str(fields["price"]))
    return fields


# ---------- Owner endpoints (declared before /{property_id}) ----------
@router.get("/mine", response_model=list[PropertyOut])
async def my_properties(user: User = Depends(owner_only), db: AsyncSession = Depends(get_db)):
    rows = await db.scalars(
        select(Property).where(Property.owner_id == user.id).order_by(Property.created_at.desc(), Property.id.desc())
    )
    return rows.all()


@router.get("/mine/{property_id}", response_model=PropertyOut)
async def my_property(property_id: int, user: User = Depends(owner_only), db: AsyncSession = Depends(get_db)):
    return await _load_owned(db, property_id, user)


@router.post("", response_model=PropertyOut, status_code=status.HTTP_201_CREATED)
async def create_property(
    data: PropertyCreate, user: User = Depends(owner_only), db: AsyncSession = Depends(get_db)
):
    prop = Property(owner_id=user.id, **_fields(data))
    _set_media(prop, data.media)
    db.add(prop)
    await db.commit()
    return await _load(db, prop.id)


@router.put("/{property_id}", response_model=PropertyOut)
async def update_property(
    property_id: int,
    data: PropertyUpdate,
    user: User = Depends(owner_only),
    db: AsyncSession = Depends(get_db),
):
    prop = await _load_owned(db, property_id, user)
    for name, value in _fields(data).items():
        setattr(prop, name, value)
    _set_media(prop, data.media)
    await db.commit()
    return await _load(db, prop.id)


@router.patch("/{property_id}/status", response_model=PropertyOut)
async def set_status(
    property_id: int,
    data: PropertyStatusIn,
    user: User = Depends(owner_only),
    db: AsyncSession = Depends(get_db),
):
    prop = await _load_owned(db, property_id, user)
    prop.is_active = data.is_active
    await db.commit()
    return await _load(db, prop.id)


@router.delete("/{property_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_property(
    property_id: int, user: User = Depends(owner_only), db: AsyncSession = Depends(get_db)
):
    prop = await _load_owned(db, property_id, user)
    await db.delete(prop)
    await db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ---------- Public endpoints ----------
@router.get("", response_model=PropertyListOut)
async def list_properties(
    q: str | None = Query(None, max_length=100),
    transaction_type: TransactionType | None = None,
    property_type: PropertyType | None = None,
    rental_period: RentalPeriod | None = None,
    scope: Scope | None = None,
    city: str | None = Query(None, max_length=80),
    min_price: float | None = Query(None, ge=0),
    max_price: float | None = Query(None, ge=0),
    amenities: Annotated[list[str] | None, Query(max_length=10)] = None,
    sort: Literal["newest", "price_asc", "price_desc"] = "newest",
    page: int = Query(1, ge=1),
    page_size: int = Query(12, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Property).where(Property.is_active.is_(True))

    if transaction_type:
        stmt = stmt.where(Property.transaction_type == transaction_type)
    if property_type:
        stmt = stmt.where(Property.property_type == property_type)
    if rental_period:
        stmt = stmt.where(Property.rental_period == rental_period)
    if scope:
        stmt = stmt.where(Property.accommodation_scope == scope)
    if city and city.strip():
        stmt = stmt.where(Property.city.ilike(f"%{city.strip()}%"))
    if q and q.strip():
        like = f"%{q.strip()}%"
        stmt = stmt.where(
            or_(
                Property.title.ilike(like),
                Property.description.ilike(like),
                Property.city.ilike(like),
                Property.address.ilike(like),
            )
        )
    if min_price is not None:
        stmt = stmt.where(Property.price >= min_price)
    if max_price is not None:
        stmt = stmt.where(Property.price <= max_price)
    for amenity in amenities or []:
        stmt = stmt.where(func.json_contains(Property.amenities, json.dumps(amenity)))

    total = await db.scalar(select(func.count()).select_from(stmt.subquery())) or 0

    ordering = {
        "newest": (Property.created_at.desc(), Property.id.desc()),
        "price_asc": (Property.price.asc(), Property.id.desc()),
        "price_desc": (Property.price.desc(), Property.id.desc()),
    }[sort]
    rows = await db.scalars(stmt.order_by(*ordering).offset((page - 1) * page_size).limit(page_size))

    return PropertyListOut(
        items=[PropertyOut.model_validate(row) for row in rows.all()],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/{property_id}", response_model=PropertyOut)
async def get_property(property_id: int, db: AsyncSession = Depends(get_db)):
    prop = await _load(db, property_id)
    if prop is None or not prop.is_active:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Property not found")
    return prop
