from fastapi import APIRouter, Depends, UploadFile

from .. import storage
from ..deps import require_role
from ..models import User
from ..schemas import UploadOut

router = APIRouter(prefix="/api/media", tags=["media"])


@router.post("/upload", response_model=UploadOut, status_code=201)
async def upload_media(file: UploadFile, user: User = Depends(require_role("owner"))):
    url, kind = await storage.save_upload(file, user.id)
    return UploadOut(url=url, media_type=kind)
