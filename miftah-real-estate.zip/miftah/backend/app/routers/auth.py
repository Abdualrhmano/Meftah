from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.concurrency import run_in_threadpool

from ..database import get_db
from ..deps import get_current_user
from ..email import send_password_reset_email, send_verification_email
from ..models import User
from ..rate_limit import rate_limit
from ..schemas import (
    AuthOut,
    ChangePasswordIn,
    DeleteAccountIn,
    ForgotPasswordIn,
    LoginIn,
    RegisterIn,
    ResetPasswordIn,
    UpdateProfileIn,
    UserOut,
    VerifyEmailIn,
)
from ..security import (
    clear_auth_cookie,
    create_access_token,
    hash_password,
    set_auth_cookie,
    verify_password,
)
from ..tokens import RESET_PASSWORD_TTL, VERIFY_EMAIL_TTL, consume_token, invalidate_pending, issue_token

router = APIRouter(prefix="/api/auth", tags=["auth"])


def redirect_for(role: str) -> str:
    """Role-based landing page: owners manage listings, clients browse."""
    return "/owner" if role == "owner" else "/client"


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _issue_session(response: Response, user: User) -> AuthOut:
    token = create_access_token(user.id, user.role)
    set_auth_cookie(response, token)
    return AuthOut(access_token=token, user=UserOut.model_validate(user), redirect_to=redirect_for(user.role))


async def _send_verification(db: AsyncSession, user: User) -> None:
    token = await issue_token(db, user, "verify_email", VERIFY_EMAIL_TTL)
    try:
        await run_in_threadpool(send_verification_email, user.email, user.name, token)
    except OSError:
        # Best-effort: a broken SMTP config shouldn't block registration/resend.
        # The user can retry from the account page once email is fixed.
        pass


@router.post("/register", response_model=AuthOut, status_code=status.HTTP_201_CREATED)
async def register(data: RegisterIn, response: Response, db: AsyncSession = Depends(get_db)):
    email = data.email.lower()
    if await db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(status.HTTP_409_CONFLICT, "Email already registered")

    password_hash = await run_in_threadpool(hash_password, data.password)
    user = User(
        name=data.name,
        email=email,
        phone=data.phone or None,
        password_hash=password_hash,
        role=data.role,
    )
    db.add(user)
    await db.flush()
    await _send_verification(db, user)
    await db.commit()
    return _issue_session(response, user)


@router.post("/login", response_model=AuthOut)
async def login(data: LoginIn, request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    email = data.email.lower()
    rate_limit(f"login-ip:{_client_ip(request)}", max_calls=20, window_seconds=900)
    rate_limit(f"login-email:{email}", max_calls=5, window_seconds=900)

    user = await db.scalar(select(User).where(User.email == email))
    valid = user is not None and await run_in_threadpool(verify_password, data.password, user.password_hash)
    if not valid:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid email or password")
    return _issue_session(response, user)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(response: Response):
    """Clears the auth cookie. Safe to call even if the caller only ever used the
    bearer token — the frontend still clears localStorage itself."""
    clear_auth_cookie(response)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/me", response_model=UserOut)
async def me(user: User = Depends(get_current_user)):
    return user


@router.patch("/me", response_model=UserOut)
async def update_me(
    data: UpdateProfileIn, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    user.name = data.name
    user.phone = data.phone or None
    await db.commit()
    return user


@router.post("/change-password", status_code=status.HTTP_204_NO_CONTENT)
async def change_password(
    data: ChangePasswordIn, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    valid = await run_in_threadpool(verify_password, data.current_password, user.password_hash)
    if not valid:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Current password is incorrect")
    user.password_hash = await run_in_threadpool(hash_password, data.new_password)
    await db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.delete("/me", status_code=status.HTTP_204_NO_CONTENT)
async def delete_me(
    data: DeleteAccountIn, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    """Deletes the account. The database cascades the deletion to that user's
    properties, conversations and messages (see the ondelete=CASCADE foreign keys
    in models.py) — media files on disk/S3 are not removed, see README limitations."""
    valid = await run_in_threadpool(verify_password, data.password, user.password_hash)
    if not valid:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect password")
    await db.delete(user)
    await db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ---------- Email verification ----------
@router.post("/verify-email", response_model=UserOut)
async def verify_email(data: VerifyEmailIn, db: AsyncSession = Depends(get_db)):
    user = await consume_token(db, data.token, "verify_email")
    if user is None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "This verification link is invalid or has expired.")
    user.is_verified = True
    await db.commit()
    return user


@router.post("/resend-verification", status_code=status.HTTP_204_NO_CONTENT)
async def resend_verification(
    user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    if user.is_verified:
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    rate_limit(f"resend-verify:{user.id}", max_calls=3, window_seconds=3600)
    await invalidate_pending(db, user.id, "verify_email")
    await _send_verification(db, user)
    await db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ---------- Password reset ----------
@router.post("/forgot-password", status_code=status.HTTP_204_NO_CONTENT)
async def forgot_password(data: ForgotPasswordIn, request: Request, db: AsyncSession = Depends(get_db)):
    email = data.email.lower()
    rate_limit(f"forgot-ip:{_client_ip(request)}", max_calls=10, window_seconds=3600)
    rate_limit(f"forgot-email:{email}", max_calls=3, window_seconds=3600)

    user = await db.scalar(select(User).where(User.email == email))
    if user is not None:
        await invalidate_pending(db, user.id, "reset_password")
        token = await issue_token(db, user, "reset_password", RESET_PASSWORD_TTL)
        try:
            await run_in_threadpool(send_password_reset_email, user.email, user.name, token)
        except OSError:
            pass
        await db.commit()
    # Same response whether or not the email exists, so this can't be used to
    # probe which addresses are registered.
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/reset-password", status_code=status.HTTP_204_NO_CONTENT)
async def reset_password(data: ResetPasswordIn, db: AsyncSession = Depends(get_db)):
    user = await consume_token(db, data.token, "reset_password")
    if user is None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "This reset link is invalid or has expired.")
    user.password_hash = await run_in_threadpool(hash_password, data.new_password)
    await invalidate_pending(db, user.id, "reset_password")
    await db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
