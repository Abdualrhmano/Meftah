from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..deps import get_current_user, require_role
from ..models import Conversation, Message, Property, User, utcnow
from ..schemas import (
    ConversationOut,
    ConversationStart,
    MessageIn,
    MessageOut,
    PropertyBrief,
    UserPublic,
)

router = APIRouter(prefix="/api/conversations", tags=["messages"])


async def _load_conversation(db: AsyncSession, conversation_id: int) -> Conversation | None:
    result = await db.execute(
        select(Conversation)
        .where(Conversation.id == conversation_id)
        .execution_options(populate_existing=True)
    )
    return result.scalar_one_or_none()


async def _participant_conversation(db: AsyncSession, conversation_id: int, user: User) -> Conversation:
    conversation = await _load_conversation(db, conversation_id)
    if conversation is None or user.id not in (conversation.client_id, conversation.owner_id):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Conversation not found")
    return conversation


async def _to_out(db: AsyncSession, conversation: Conversation, me: User) -> ConversationOut:
    other = conversation.owner if me.id == conversation.client_id else conversation.client
    last = await db.scalar(
        select(Message).where(Message.conversation_id == conversation.id).order_by(Message.id.desc()).limit(1)
    )
    unread = await db.scalar(
        select(func.count())
        .select_from(Message)
        .where(
            Message.conversation_id == conversation.id,
            Message.sender_id != me.id,
            Message.read_at.is_(None),
        )
    )
    prop = conversation.property
    cover = next((m.url for m in prop.media if m.media_type == "image"), None)
    return ConversationOut(
        id=conversation.id,
        property=PropertyBrief(id=prop.id, title=prop.title, cover_url=cover),
        other_user=UserPublic(id=other.id, name=other.name),
        last_message=MessageOut.model_validate(last) if last else None,
        unread_count=unread or 0,
        updated_at=conversation.updated_at,
    )


@router.get("/unread-count")
async def unread_count(me: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    count = await db.scalar(
        select(func.count())
        .select_from(Message)
        .join(Conversation, Conversation.id == Message.conversation_id)
        .where(
            or_(Conversation.client_id == me.id, Conversation.owner_id == me.id),
            Message.sender_id != me.id,
            Message.read_at.is_(None),
        )
    )
    return {"count": count or 0}


@router.get("", response_model=list[ConversationOut])
async def list_conversations(me: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    rows = await db.scalars(
        select(Conversation)
        .where(or_(Conversation.client_id == me.id, Conversation.owner_id == me.id))
        .order_by(Conversation.updated_at.desc())
        .limit(100)
    )
    return [await _to_out(db, conversation, me) for conversation in rows.all()]


@router.post("", response_model=ConversationOut, status_code=status.HTTP_201_CREATED)
async def start_conversation(
    data: ConversationStart,
    me: User = Depends(require_role("client")),
    db: AsyncSession = Depends(get_db),
):
    prop = await db.get(Property, data.property_id)
    if prop is None or not prop.is_active:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Property not found")

    lookup = select(Conversation.id).where(
        Conversation.property_id == prop.id, Conversation.client_id == me.id
    )
    conversation_id = await db.scalar(lookup)
    if conversation_id is None:
        conversation = Conversation(property_id=prop.id, client_id=me.id, owner_id=prop.owner_id)
        db.add(conversation)
        try:
            await db.flush()
            conversation_id = conversation.id
        except IntegrityError:  # two requests raced; reuse the winner's thread
            await db.rollback()
            conversation_id = await db.scalar(lookup)

    db.add(Message(conversation_id=conversation_id, sender_id=me.id, body=data.body))
    await db.execute(
        update(Conversation).where(Conversation.id == conversation_id).values(updated_at=utcnow())
    )
    await db.commit()

    conversation = await _load_conversation(db, conversation_id)
    return await _to_out(db, conversation, me)


@router.get("/{conversation_id}/messages", response_model=list[MessageOut])
async def list_messages(
    conversation_id: int,
    after_id: int = Query(0, ge=0),
    me: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    conversation = await _participant_conversation(db, conversation_id, me)

    # Opening the thread marks the other side's messages as read.
    await db.execute(
        update(Message)
        .where(
            Message.conversation_id == conversation.id,
            Message.sender_id != me.id,
            Message.read_at.is_(None),
        )
        .values(read_at=utcnow())
    )
    await db.commit()

    rows = await db.scalars(
        select(Message)
        .where(Message.conversation_id == conversation.id, Message.id > after_id)
        .order_by(Message.id.asc())
        .limit(500)
    )
    return rows.all()


@router.post("/{conversation_id}/messages", response_model=MessageOut, status_code=status.HTTP_201_CREATED)
async def send_message(
    conversation_id: int,
    data: MessageIn,
    me: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    conversation = await _participant_conversation(db, conversation_id, me)
    message = Message(conversation_id=conversation.id, sender_id=me.id, body=data.body)
    db.add(message)
    conversation.updated_at = utcnow()
    await db.commit()
    return message
