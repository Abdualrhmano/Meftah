"""Outbound email for verification and password-reset links.

Without SMTP configured (the development default), messages are printed to the
server console instead of sent — the flow still works end-to-end, you just read
the link from the logs rather than an inbox. Set smtp_host in .env to send real
email through any SMTP provider (SES, Postmark, Gmail, etc).
"""
import smtplib
from email.message import EmailMessage

from .config import settings


def send_mail(to: str, subject: str, text: str) -> None:
    if not settings.smtp_host:
        print(f"\n----- DEV EMAIL (no SMTP configured) -----\nTo: {to}\nSubject: {subject}\n\n{text}\n" "-------------------------------------------\n")
        return

    message = EmailMessage()
    message["From"] = settings.smtp_from
    message["To"] = to
    message["Subject"] = subject
    message.set_content(text)

    with smtplib.SMTP(settings.smtp_host, settings.smtp_port) as smtp:
        if settings.smtp_use_tls:
            smtp.starttls()
        if settings.smtp_user:
            smtp.login(settings.smtp_user, settings.smtp_password)
        smtp.send_message(message)


def send_verification_email(to: str, name: str, token: str) -> None:
    link = f"{settings.frontend_url.rstrip('/')}/verify-email?token={token}"
    send_mail(
        to,
        "Confirm your email — Miftah",
        f"Hi {name},\n\nConfirm your email address to finish setting up your Miftah account:\n{link}\n\n"
        "This link expires in 24 hours. If you didn't create this account, you can ignore this email.",
    )


def send_password_reset_email(to: str, name: str, token: str) -> None:
    link = f"{settings.frontend_url.rstrip('/')}/reset-password?token={token}"
    send_mail(
        to,
        "Reset your password — Miftah",
        f"Hi {name},\n\nWe received a request to reset your Miftah password:\n{link}\n\n"
        "This link expires in 1 hour. If you didn't request this, you can ignore this email — "
        "your password won't change.",
    )
