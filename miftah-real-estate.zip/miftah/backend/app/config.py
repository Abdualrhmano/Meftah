from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "mysql+aiomysql://root:password@localhost:3306/realestate?charset=utf8mb4"
    # Dev convenience: creates missing tables on startup. Set to false once you manage
    # the schema with Alembic migrations (see backend/migrations/), so app restarts never
    # race a migration or silently paper over a schema drift.
    auto_create_tables: bool = True

    secret_key: str = "change-me"
    access_token_expire_minutes: int = 60 * 24 * 7

    cors_origins: str = "http://localhost:3000"

    storage_backend: str = "local"  # "local" | "s3"
    local_upload_dir: str = "uploads"
    public_base_url: str = "http://localhost:8000"

    s3_bucket: str = ""
    s3_region: str = "us-east-1"
    s3_public_base_url: str = ""

    max_image_mb: int = 10
    max_video_mb: int = 100

    # Public URL of the Next.js frontend, used to build links inside emails
    # (email verification, password reset).
    frontend_url: str = "http://localhost:3000"

    # If true, unverified owners cannot publish listings. Off by default so this
    # feature is purely additive until you decide to enforce it.
    require_email_verification: bool = False

    # Auth cookie: set alongside the existing bearer token as a second, httpOnly
    # transport. The frontend still runs on the Authorization header + localStorage
    # token by default; the cookie is there so a future full migration to
    # cookie-only auth doesn't require backend changes. Set true once served over
    # HTTPS in production.
    cookie_secure: bool = False

    # --- Outbound email (verification, password reset) ---
    # Leave smtp_host empty in development: emails are printed to the server
    # console instead of being sent, so the flow works without any SMTP setup.
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = "Miftah <no-reply@example.com>"
    smtp_use_tls: bool = True

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


settings = Settings()
