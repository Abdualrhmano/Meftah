from datetime import datetime, timezone
from typing import Annotated, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
    PlainSerializer,
    field_validator,
    model_validator,
)

Role = Literal["client", "owner"]
PropertyType = Literal["apartment", "building", "land"]
TransactionType = Literal["sale", "rent"]
RentalPeriod = Literal["daily", "monthly"]
Scope = Literal["whole", "bed"]
Currency = Literal["EGP", "SAR", "AED", "USD", "EUR"]


def _iso_utc(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


# Naive UTC datetimes from MySQL are always serialized with a trailing "Z".
UTCDateTime = Annotated[datetime, PlainSerializer(_iso_utc, return_type=str)]


# ---------- Auth ----------
class RegisterIn(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    role: Role
    phone: str | None = Field(default=None, max_length=32)


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=72)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    email: str
    phone: str | None
    role: Role
    is_verified: bool


class UpdateProfileIn(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    name: str = Field(min_length=2, max_length=120)
    phone: str | None = Field(default=None, max_length=32)


class ChangePasswordIn(BaseModel):
    current_password: str = Field(min_length=1, max_length=72)
    new_password: str = Field(min_length=8, max_length=72)


class DeleteAccountIn(BaseModel):
    password: str = Field(min_length=1, max_length=72)


class ForgotPasswordIn(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    email: EmailStr


class ResetPasswordIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)
    new_password: str = Field(min_length=8, max_length=72)


class VerifyEmailIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)


class UserPublic(BaseModel):
    """What other users are allowed to see about someone (no email / phone)."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str


class AuthOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut
    redirect_to: str


# ---------- Properties ----------
class MediaIn(BaseModel):
    url: str = Field(max_length=500)
    media_type: Literal["image", "video"]


class MediaOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    url: str
    media_type: Literal["image", "video"]
    sort_order: int


class PropertyCreate(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    title: str = Field(min_length=3, max_length=200)
    property_type: PropertyType
    transaction_type: TransactionType
    rental_period: RentalPeriod | None = None
    accommodation_scope: Scope = "whole"
    beds_available: int | None = Field(default=None, ge=1, le=500)
    description: str = Field(min_length=1, max_length=5000)
    price: float = Field(gt=0, lt=1e12)
    currency: Currency = "EGP"
    city: str = Field(min_length=2, max_length=80)
    address: str | None = Field(default=None, max_length=255)
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)
    amenities: list[str] = Field(default_factory=list)
    media: list[MediaIn] = Field(default_factory=list, max_length=30)

    @field_validator("amenities")
    @classmethod
    def clean_amenities(cls, value: list[str]) -> list[str]:
        cleaned: list[str] = []
        for item in value:
            item = item.strip()
            if item and len(item) <= 60 and item not in cleaned:
                cleaned.append(item)
        return cleaned[:30]

    @model_validator(mode="after")
    def check_rules(self):
        if self.transaction_type == "rent":
            if self.rental_period is None:
                raise ValueError("rental_period is required for rentals (daily or monthly)")
            if self.accommodation_scope == "bed":
                if self.property_type == "land":
                    raise ValueError("Land cannot be rented by the bed")
                if not self.beds_available:
                    raise ValueError("beds_available is required when renting by the bed")
            else:
                self.beds_available = None
        else:
            # Sales are always for the whole property.
            self.rental_period = None
            self.accommodation_scope = "whole"
            self.beds_available = None

        if (self.latitude is None) != (self.longitude is None):
            raise ValueError("latitude and longitude must be provided together")
        return self


PropertyUpdate = PropertyCreate


class PropertyStatusIn(BaseModel):
    is_active: bool


class PropertyOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    owner_id: int
    owner: UserPublic
    title: str
    property_type: PropertyType
    transaction_type: TransactionType
    rental_period: RentalPeriod | None
    accommodation_scope: Scope
    beds_available: int | None
    description: str
    price: float
    currency: str
    city: str
    address: str | None
    latitude: float | None
    longitude: float | None
    amenities: list[str]
    is_active: bool
    created_at: UTCDateTime
    media: list[MediaOut]

    @field_validator("price", mode="before")
    @classmethod
    def price_to_float(cls, value):
        return float(value)


class PropertyListOut(BaseModel):
    items: list[PropertyOut]
    total: int
    page: int
    page_size: int


# ---------- Messaging ----------
class ConversationStart(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    property_id: int
    body: str = Field(min_length=1, max_length=4000)


class MessageIn(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    body: str = Field(min_length=1, max_length=4000)


class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    conversation_id: int
    sender_id: int
    body: str
    created_at: UTCDateTime
    read_at: UTCDateTime | None


class PropertyBrief(BaseModel):
    id: int
    title: str
    cover_url: str | None


class ConversationOut(BaseModel):
    id: int
    property: PropertyBrief
    other_user: UserPublic
    last_message: MessageOut | None
    unread_count: int
    updated_at: UTCDateTime


class UploadOut(BaseModel):
    url: str
    media_type: Literal["image", "video"]
