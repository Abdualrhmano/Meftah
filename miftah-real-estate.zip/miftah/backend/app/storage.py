"""Media storage: local disk for development, AWS S3 (or S3-compatible) for production."""
import shutil
import uuid
from functools import lru_cache
from pathlib import Path
from typing import BinaryIO

from fastapi import HTTPException, UploadFile
from starlette.concurrency import run_in_threadpool

from .config import settings

ALLOWED_TYPES = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "video/mp4": ".mp4",
    "video/webm": ".webm",
    "video/quicktime": ".mov",
}


def _signature_ok(head: bytes, content_type: str) -> bool:
    """Check the real file header so a renamed .exe/.html can't pose as an image."""
    if content_type == "image/jpeg":
        return head.startswith(b"\xff\xd8\xff")
    if content_type == "image/png":
        return head.startswith(b"\x89PNG\r\n\x1a\n")
    if content_type == "image/webp":
        return head[:4] == b"RIFF" and head[8:12] == b"WEBP"
    if content_type == "video/webm":
        return head.startswith(b"\x1a\x45\xdf\xa3")
    if content_type in ("video/mp4", "video/quicktime"):
        return head[4:8] == b"ftyp"
    return False


def public_base() -> str:
    if settings.storage_backend == "s3":
        if settings.s3_public_base_url:
            return settings.s3_public_base_url.rstrip("/")
        return f"https://{settings.s3_bucket}.s3.{settings.s3_region}.amazonaws.com"
    return f"{settings.public_base_url.rstrip('/')}/uploads"


def is_own_url(url: str) -> bool:
    """Listings may only reference files that were uploaded through this API."""
    return url.startswith(public_base() + "/")


@lru_cache
def _s3_client():
    import boto3

    return boto3.client("s3", region_name=settings.s3_region)


def _put_s3(stream: BinaryIO, key: str, content_type: str) -> None:
    _s3_client().upload_fileobj(
        stream,
        settings.s3_bucket,
        key,
        ExtraArgs={
            "ContentType": content_type,
            "CacheControl": "public, max-age=31536000, immutable",
        },
    )


def _put_local(stream: BinaryIO, key: str) -> None:
    dest = Path(settings.local_upload_dir) / key
    dest.parent.mkdir(parents=True, exist_ok=True)
    with open(dest, "wb") as out:
        shutil.copyfileobj(stream, out)


async def save_upload(file: UploadFile, owner_id: int) -> tuple[str, str]:
    """Validate and store an uploaded file. Returns (public_url, "image" | "video")."""
    content_type = (file.content_type or "").lower()
    if content_type not in ALLOWED_TYPES:
        raise HTTPException(415, "Unsupported file type. Allowed: JPEG, PNG, WebP, MP4, WebM, MOV")

    kind = "image" if content_type.startswith("image/") else "video"
    limit_mb = settings.max_image_mb if kind == "image" else settings.max_video_mb

    stream = file.file
    stream.seek(0, 2)
    size = stream.tell()
    stream.seek(0)
    if size == 0:
        raise HTTPException(400, "Empty file")
    if size > limit_mb * 1024 * 1024:
        raise HTTPException(413, f"File too large. Maximum for {kind}s is {limit_mb} MB")

    head = stream.read(16)
    stream.seek(0)
    if not _signature_ok(head, content_type):
        raise HTTPException(415, "File content does not match its declared type")

    key = f"properties/{owner_id}/{uuid.uuid4().hex}{ALLOWED_TYPES[content_type]}"
    if settings.storage_backend == "s3":
        await run_in_threadpool(_put_s3, stream, key, content_type)
    else:
        await run_in_threadpool(_put_local, stream, key)
    return f"{public_base()}/{key}", kind
