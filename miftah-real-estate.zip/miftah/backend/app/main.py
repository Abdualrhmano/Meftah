import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .config import settings
from .database import Base, engine
from .routers import auth, conversations, media, properties


@asynccontextmanager
async def lifespan(_: FastAPI):
    if settings.secret_key == "change-me":
        print("WARNING: SECRET_KEY is the default value. Set a strong one in .env before deploying.")
    if settings.auto_create_tables:
        # Dev convenience only. In production, run `alembic upgrade head` instead and set
        # AUTO_CREATE_TABLES=false so this never fights with a migration.
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    yield
    await engine.dispose()


app = FastAPI(title="Miftah Real Estate API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(properties.router)
app.include_router(media.router)
app.include_router(conversations.router)

if settings.storage_backend == "local":
    os.makedirs(settings.local_upload_dir, exist_ok=True)
    app.mount("/uploads", StaticFiles(directory=settings.local_upload_dir), name="uploads")


@app.get("/api/health", tags=["meta"])
async def health():
    return {"status": "ok"}
