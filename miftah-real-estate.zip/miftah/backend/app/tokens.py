"""Single-use tokens for email verification and password reset (see AuthToken)."""
import hashlib
import secrets
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .models import AuthToken, User, utcnow

VERIFY_EMAIL_TTL = timedelta(hours=24)
RESET_PASSWORD_TTL = timedelta(hours=1)


def _hash(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


async def issue_token(db: AsyncSession, user: User, purpose: str, ttl: timedelta) -> str:
    """Creates a token, stores only its hash, and returns the raw value to send by email."""
    raw = secrets.token_urlsafe(32)
    db.add(
        AuthToken(
            user_id=user.id,
            token_hash=_hash(raw),
            purpose=purpose,
            expires_at=datetime.now(timezone.utc).replace(tzinfo=None) + ttl,
        )
    )
    await db.flush()
    return raw


async def consume_token(db: AsyncSession, raw: str, purpose: str) -> User | None:
    """Validates a token (right purpose, unused, unexpired), marks it used, and returns its owner."""
    row = await db.scalar(
        select(AuthToken).where(AuthToken.token_hash == _hash(raw), AuthToken.purpose == purpose)
    )
    if row is None or row.used_at is not None or row.expires_at < utcnow():
        return None
    row.used_at = utcnow()
    user = await db.get(User, row.user_id)
    return user


async def invalidate_pending(db: AsyncSession, user_id: int, purpose: str) -> None:
    """Marks any earlier unused tokens of this purpose as used, so only the newest link works."""
    await db.execute(
        update(AuthToken)
        .where(AuthToken.user_id == user_id, AuthToken.purpose == purpose, AuthToken.used_at.is_(None))
        .values(used_at=utcnow())
    )
