export const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
export const TOKEN_KEY = "miftah_token";

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(TOKEN_KEY);
}

type Options = Omit<RequestInit, "body"> & { json?: unknown; body?: BodyInit | null };

/** Browser-side API call. Adds the bearer token and turns errors into ApiError. */
export async function api<T>(path: string, options: Options = {}): Promise<T> {
  const { json, body, headers: extraHeaders, ...rest } = options;
  const headers = new Headers(extraHeaders);
  const token = getToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);

  let payload: BodyInit | null | undefined = body;
  if (json !== undefined) {
    headers.set("Content-Type", "application/json");
    payload = JSON.stringify(json);
  }

  const res = await fetch(`${API_URL}${path}`, { ...rest, headers, body: payload });

  if (!res.ok) {
    let message = res.statusText;
    try {
      const data = await res.json();
      if (typeof data.detail === "string") message = data.detail;
      else if (Array.isArray(data.detail)) message = data.detail.map((d: { msg: string }) => d.msg).join(", ");
    } catch {
      /* body was not JSON */
    }
    throw new ApiError(res.status, message);
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

/** Server-component fetch (used by SEO pages). Returns null on any failure. */
export async function serverFetch<T>(path: string): Promise<T | null> {
  const base = process.env.API_URL ?? API_URL;
  try {
    const res = await fetch(`${base}${path}`, { cache: "no-store" });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}
