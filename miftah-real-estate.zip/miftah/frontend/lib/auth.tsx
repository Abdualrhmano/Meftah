"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api, TOKEN_KEY } from "./api";
import type { AuthResponse, Role, User } from "./types";

interface RegisterData {
  name: string;
  email: string;
  password: string;
  role: Role;
  phone?: string;
}

interface AuthValue {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<AuthResponse>;
  register: (data: RegisterData) => Promise<AuthResponse>;
  logout: () => void;
  /** Re-reads the profile from the API and updates the cached user (e.g. after editing it). */
  refresh: () => Promise<User>;
}

const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!window.localStorage.getItem(TOKEN_KEY)) {
      setLoading(false);
      return;
    }
    api<User>("/api/auth/me")
      .then(setUser)
      .catch(() => window.localStorage.removeItem(TOKEN_KEY))
      .finally(() => setLoading(false));
  }, []);

  const finish = useCallback((res: AuthResponse) => {
    window.localStorage.setItem(TOKEN_KEY, res.access_token);
    setUser(res.user);
    return res;
  }, []);

  const login = useCallback(
    async (email: string, password: string) =>
      finish(await api<AuthResponse>("/api/auth/login", { method: "POST", json: { email, password } })),
    [finish],
  );

  const register = useCallback(
    async (data: RegisterData) =>
      finish(await api<AuthResponse>("/api/auth/register", { method: "POST", json: data })),
    [finish],
  );

  const logout = useCallback(() => {
    window.localStorage.removeItem(TOKEN_KEY);
    setUser(null);
    // Best-effort: also clears the httpOnly session cookie. The app doesn't
    // depend on this cookie today (it reads the header token above), so a
    // failure here is silently ignored.
    api("/api/auth/logout", { method: "POST" }).catch(() => undefined);
  }, []);

  const refresh = useCallback(async () => {
    const fresh = await api<User>("/api/auth/me");
    setUser(fresh);
    return fresh;
  }, []);

  const value = useMemo(
    () => ({ user, loading, login, register, logout, refresh }),
    [user, loading, login, register, logout, refresh],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}

export const homeFor = (role: Role) => (role === "owner" ? "/owner" : "/client");

/** Only follow ?next= when it is a local path that this role is allowed to open. */
export function safeNext(next: string | null, role: Role): string | null {
  if (!next || !next.startsWith("/") || next.startsWith("//")) return null;
  if (next.startsWith("/owner") && role !== "owner") return null;
  if (next.startsWith("/client") && role !== "client") return null;
  return next;
}
