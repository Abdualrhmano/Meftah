import { cookies } from "next/headers";
import { dictionaries, makeT, type Locale } from "./dictionary";

export async function getLocale(): Promise<Locale> {
  const value = (await cookies()).get("locale")?.value;
  return value === "en" ? "en" : "ar";
}

export async function getT() {
  const locale = await getLocale();
  return { locale, t: makeT(dictionaries[locale]) };
}
