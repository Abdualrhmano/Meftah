import type { T, Locale } from "./dictionary";
import type { Property } from "./types";

export const localeTag = (locale: Locale) => (locale === "ar" ? "ar-EG" : "en-US");

export function formatNumber(value: number, locale: Locale): string {
  return new Intl.NumberFormat(localeTag(locale), { maximumFractionDigits: 2 }).format(value);
}

export function formatDate(iso: string, locale: Locale): string {
  return new Intl.DateTimeFormat(localeTag(locale), { dateStyle: "medium" }).format(new Date(iso));
}

export function formatTime(iso: string, locale: Locale): string {
  return new Intl.DateTimeFormat(localeTag(locale), { timeStyle: "short" }).format(new Date(iso));
}

export function formatDateTime(iso: string, locale: Locale): string {
  return new Intl.DateTimeFormat(localeTag(locale), { dateStyle: "medium", timeStyle: "short" }).format(new Date(iso));
}

export function coverOf(property: Pick<Property, "media">): string | null {
  return property.media.find((m) => m.media_type === "image")?.url ?? null;
}

/** "4,500,000 EGP" + optional unit such as "/ month" (or "/ month per bed"). */
export function priceParts(p: Property, t: T, locale: Locale): { amount: string; unit: string | null } {
  const amount = p.price > 0 ? `${formatNumber(p.price, locale)} ${t(`cur.${p.currency}`)}` : "—";
  if (p.transaction_type !== "rent" || p.price <= 0) return { amount, unit: null };
  let unit = p.rental_period === "daily" ? t("unit.perDay") : t("unit.perMonth");
  if (p.accommodation_scope === "bed") unit = `${unit} ${t("unit.forBed")}`;
  return { amount, unit };
}

export function amenityLabel(slug: string, t: T): string {
  const key = `amenity.${slug}`;
  const label = t(key);
  return label === key ? slug : label;
}
