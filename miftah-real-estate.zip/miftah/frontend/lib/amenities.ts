/** Predefined amenity slugs. Labels live in the dictionary as `amenity.<slug>`. Owners can also add custom text. */
export const AMENITIES = [
  "wifi",
  "parking",
  "ac",
  "heating",
  "security",
  "elevator",
  "furnished",
  "kitchen",
  "washer",
  "tv",
  "water",
  "electricity",
  "balcony",
  "garden",
  "pool",
  "gym",
  "pets",
] as const;

export const FILTER_AMENITIES = ["wifi", "parking", "ac", "security", "elevator", "furnished"] as const;
export const CURRENCIES = ["EGP", "SAR", "AED", "USD", "EUR"] as const;
