export type Role = "client" | "owner";
export type PropertyType = "apartment" | "building" | "land";
export type TransactionType = "sale" | "rent";
export type RentalPeriod = "daily" | "monthly";
export type Scope = "whole" | "bed";

export interface User {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  role: Role;
  is_verified: boolean;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: User;
  redirect_to: string;
}

export interface Media {
  id: number;
  url: string;
  media_type: "image" | "video";
  sort_order: number;
}

export interface UserPublic {
  id: number;
  name: string;
}

export interface Property {
  id: number;
  owner_id: number;
  owner: UserPublic;
  title: string;
  property_type: PropertyType;
  transaction_type: TransactionType;
  rental_period: RentalPeriod | null;
  accommodation_scope: Scope;
  beds_available: number | null;
  description: string;
  price: number;
  currency: string;
  city: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  amenities: string[];
  is_active: boolean;
  created_at: string;
  media: Media[];
}

export interface PropertyList {
  items: Property[];
  total: number;
  page: number;
  page_size: number;
}

export interface Message {
  id: number;
  conversation_id: number;
  sender_id: number;
  body: string;
  created_at: string;
  read_at: string | null;
}

export interface Conversation {
  id: number;
  property: { id: number; title: string; cover_url: string | null };
  other_user: UserPublic;
  last_message: Message | null;
  unread_count: number;
  updated_at: string;
}
