"use client";

import { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode } from "react";
import Icon from "./Icons";

interface ToastItem {
  id: number;
  message: string;
  tone: "ok" | "error";
}

interface ToastValue {
  show: (message: string, tone?: "ok" | "error") => void;
}

const ToastContext = createContext<ToastValue | null>(null);

/** Short status messages that survive page navigation (the provider lives in the root layout). */
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const counter = useRef(0);

  const dismiss = useCallback((id: number) => setItems((list) => list.filter((t) => t.id !== id)), []);

  const show = useCallback(
    (message: string, tone: "ok" | "error" = "ok") => {
      const id = ++counter.current;
      setItems((list) => [...list.slice(-2), { id, message, tone }]);
      setTimeout(() => dismiss(id), 4500);
    },
    [dismiss],
  );

  const value = useMemo(() => ({ show }), [show]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {items.map((item) => (
          <p key={item.id} className={`toast ${item.tone}`}>
            <Icon name={item.tone === "ok" ? "check" : "x"} size={16} />
            <span>{item.message}</span>
          </p>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside <ToastProvider>");
  return ctx;
}
