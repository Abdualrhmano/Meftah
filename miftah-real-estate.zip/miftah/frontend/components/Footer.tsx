import Link from "next/link";
import { getT } from "@/lib/i18n-server";

export default async function Footer() {
  const { t } = await getT();
  return (
    <footer className="site-footer">
      <div className="container footer-row">
        <p>
          <strong>{t("brand")}</strong> — {t("footer.tagline")}
        </p>
        <nav aria-label={t("footer.nav")}>
          <Link href="/properties">{t("nav.browse")}</Link>
          <Link href="/register?role=owner">{t("footer.listYours")}</Link>
        </nav>
      </div>
    </footer>
  );
}
