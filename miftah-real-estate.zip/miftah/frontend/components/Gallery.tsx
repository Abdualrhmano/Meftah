"use client";

import { useEffect, useRef, useState } from "react";
import { formatNumber } from "@/lib/format";
import { useI18n } from "@/lib/i18n-client";
import type { Media, PropertyType } from "@/lib/types";
import { FacadeArt } from "./Art";
import Icon from "./Icons";

export default function Gallery({
  media,
  kind,
  title,
}: {
  media: Media[];
  kind: PropertyType | "bed";
  title: string;
}) {
  const { t, locale } = useI18n();
  const [index, setIndex] = useState(0);
  const [zoomed, setZoomed] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    if (zoomed) dialog.current?.showModal();
  }, [zoomed]);

  if (media.length === 0) {
    return (
      <div className="gallery-main gallery-empty">
        <FacadeArt kind={kind} />
      </div>
    );
  }

  const current = media[Math.min(index, media.length - 1)];
  const go = (delta: number) => setIndex((i) => (i + delta + media.length) % media.length);
  const counter = `${formatNumber(index + 1, locale)} / ${formatNumber(media.length, locale)}`;

  const nav = media.length > 1 && (
    <>
      <button type="button" className="gallery-nav prev" onClick={() => go(-1)} aria-label={t("detail.prev")}>
        <Icon name="chevron" size={22} />
      </button>
      <button type="button" className="gallery-nav next" onClick={() => go(1)} aria-label={t("detail.next")}>
        <Icon name="chevron" size={22} />
      </button>
    </>
  );

  return (
    <section aria-label={t("detail.gallery")}>
      <div className="gallery-main">
        {current.media_type === "image" ? (
          <button type="button" className="gallery-zoom" onClick={() => setZoomed(true)} aria-label={t("detail.enlarge")}>
            <img src={current.url} alt={title} />
          </button>
        ) : (
          <video key={current.id} src={current.url} controls playsInline preload="metadata" />
        )}
        {nav}
        {media.length > 1 && <span className="gallery-count">{counter}</span>}
      </div>

      {media.length > 1 && (
        <ul className="gallery-thumbs">
          {media.map((m, i) => (
            <li key={m.id}>
              <button
                type="button"
                onClick={() => setIndex(i)}
                aria-current={i === index}
                aria-label={t("detail.showMedia", { n: i + 1 })}
              >
                {m.media_type === "image" ? (
                  <img src={m.url} alt="" loading="lazy" />
                ) : (
                  <span className="thumb-video">
                    <Icon name="play" />
                  </span>
                )}
              </button>
            </li>
          ))}
        </ul>
      )}

      {zoomed && (
        <dialog
          ref={dialog}
          className="lightbox"
          aria-label={title}
          onClose={() => setZoomed(false)}
          onClick={(e) => e.target === e.currentTarget && dialog.current?.close()}
        >
          <div className="lightbox-body">
            {current.media_type === "image" ? (
              <img src={current.url} alt={title} />
            ) : (
              <video key={current.id} src={current.url} controls playsInline />
            )}
            {nav}
            <button type="button" className="lightbox-close" onClick={() => dialog.current?.close()} aria-label={t("detail.close")}>
              <Icon name="x" size={22} />
            </button>
            <span className="gallery-count">{counter}</span>
          </div>
        </dialog>
      )}
    </section>
  );
}
