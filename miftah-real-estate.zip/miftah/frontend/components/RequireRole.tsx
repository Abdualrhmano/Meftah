"use client";

import { useEffect, type ReactNode } from "react";
import { usePathname, useRouter } from "next/navigation";
import { homeFor, useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n-client";
import type { Role } from "@/lib/types";

/** Client-side route guard. The API enforces the same rules, this only keeps people on the right screens. */
export default function RequireRole({ role, children }: { role?: Role; children: ReactNode }) {
  const { user, loading } = useAuth();
  const { t } = useI18n();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace(`/login?next=${encodeURIComponent(pathname)}`);
    } else if (role && user.role !== role) {
      router.replace(homeFor(user.role));
    }
  }, [loading, user, role, router, pathname]);

  if (loading || !user || (role && user.role !== role)) {
    return <p className="page-loading container">{t("common.loading")}</p>;
  }
  return <>{children}</>;
}
