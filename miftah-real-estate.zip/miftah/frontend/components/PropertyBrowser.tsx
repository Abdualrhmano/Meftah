"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { api } from "@/lib/api";
import { FILTER_AMENITIES } from "@/lib/amenities";
import { amenityLabel } from "@/lib/format";
import { useI18n } from "@/lib/i18n-client";
import type { PropertyList, PropertyType, RentalPeriod, Scope, TransactionType } from "@/lib/types";
import Icon from "./Icons";
import { CardSkeleton, PropertyGrid } from "./PropertyCard";
import Segmented from "./Segmented";

type Sort = "newest" | "price_asc" | "price_desc";

interface Filters {
  q: string;
  transaction_type: "" | TransactionType;
  property_type: "" | PropertyType;
  rental_period: "" | RentalPeriod;
  scope: "" | Scope;
  city: string;
  min_price: string;
  max_price: string;
  amenities: string[];
  sort: Sort;
}

const EMPTY: Filters = {
  q: "",
  transaction_type: "",
  property_type: "",
  rental_period: "",
  scope: "",
  city: "",
  min_price: "",
  max_price: "",
  amenities: [],
  sort: "newest",
};

function pick<T extends string>(value: string | null, allowed: readonly T[]): T | "" {
  return allowed.includes(value as T) ? (value as T) : "";
}

export default function PropertyBrowser() {
  const { t } = useI18n();
  const params = useSearchParams();

  const [filters, setFilters] = useState<Filters>(() => {
    const transaction_type = pick(params.get("transaction_type"), ["sale", "rent"] as const);
    return {
      ...EMPTY,
      q: params.get("q") ?? "",
      transaction_type,
      property_type: pick(params.get("property_type"), ["apartment", "building", "land"] as const),
      rental_period: transaction_type === "rent" ? pick(params.get("rental_period"), ["daily", "monthly"] as const) : "",
      scope: transaction_type === "rent" ? pick(params.get("scope"), ["whole", "bed"] as const) : "",
    };
  });
  const [page, setPage] = useState(1);
  const [data, setData] = useState<PropertyList | null>(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);
  const [panelOpen, setPanelOpen] = useState(false);

  function update(patch: Partial<Filters>) {
    setFilters((prev) => {
      const next = { ...prev, ...patch };
      if (next.transaction_type !== "rent") {
        next.rental_period = "";
        next.scope = "";
      }
      return next;
    });
    setPage(1);
  }

  function clear() {
    setFilters(EMPTY);
    setPage(1);
  }

  useEffect(() => {
    const controller = new AbortController();
    const timer = setTimeout(async () => {
      setLoading(true);
      setFailed(false);
      try {
        const qs = new URLSearchParams();
        if (filters.q.trim()) qs.set("q", filters.q.trim());
        if (filters.transaction_type) qs.set("transaction_type", filters.transaction_type);
        if (filters.property_type) qs.set("property_type", filters.property_type);
        if (filters.rental_period) qs.set("rental_period", filters.rental_period);
        if (filters.scope) qs.set("scope", filters.scope);
        if (filters.city.trim()) qs.set("city", filters.city.trim());
        if (filters.min_price) qs.set("min_price", filters.min_price);
        if (filters.max_price) qs.set("max_price", filters.max_price);
        filters.amenities.forEach((a) => qs.append("amenities", a));
        qs.set("sort", filters.sort);
        qs.set("page", String(page));
        qs.set("page_size", "12");
        setData(await api<PropertyList>(`/api/properties?${qs}`, { signal: controller.signal }));
      } catch (err) {
        if ((err as Error).name !== "AbortError") setFailed(true);
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }, 250);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [filters, page]);

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.page_size)) : 1;

  const applied: { key: string; label: string; remove: () => void }[] = [];
  if (filters.q.trim()) applied.push({ key: "q", label: `“${filters.q.trim()}”`, remove: () => update({ q: "" }) });
  if (filters.transaction_type)
    applied.push({ key: "tx", label: t(`tx.${filters.transaction_type}`), remove: () => update({ transaction_type: "" }) });
  if (filters.property_type)
    applied.push({ key: "type", label: t(`ptype.${filters.property_type}`), remove: () => update({ property_type: "" }) });
  if (filters.rental_period)
    applied.push({ key: "period", label: t(`period.${filters.rental_period}`), remove: () => update({ rental_period: "" }) });
  if (filters.scope) applied.push({ key: "scope", label: t(`scope.${filters.scope}`), remove: () => update({ scope: "" }) });
  if (filters.city.trim()) applied.push({ key: "city", label: filters.city.trim(), remove: () => update({ city: "" }) });
  if (filters.min_price)
    applied.push({ key: "min", label: `${t("filters.minPrice")}: ${filters.min_price}`, remove: () => update({ min_price: "" }) });
  if (filters.max_price)
    applied.push({ key: "max", label: `${t("filters.maxPrice")}: ${filters.max_price}`, remove: () => update({ max_price: "" }) });
  filters.amenities.forEach((a) =>
    applied.push({
      key: `a-${a}`,
      label: amenityLabel(a, t),
      remove: () => update({ amenities: filters.amenities.filter((x) => x !== a) }),
    }),
  );

  return (
    <div className="browser container">
      <aside className={`filters${panelOpen ? " open" : ""}`}>
        <button
          type="button"
          className="btn ghost filters-toggle"
          onClick={() => setPanelOpen((o) => !o)}
          aria-expanded={panelOpen}
        >
          {t("filters.title")}
          {applied.length > 0 && <span className="badge">{applied.length}</span>}
        </button>

        <div className="filters-body">
          <div className="field">
            <label htmlFor="f-q">{t("filters.search")}</label>
            <input
              id="f-q"
              type="search"
              value={filters.q}
              onChange={(e) => update({ q: e.target.value })}
              placeholder={t("filters.searchPlaceholder")}
            />
          </div>

          <Segmented
            name="f-tx"
            legend={t("filters.transaction")}
            value={filters.transaction_type}
            onChange={(v) => update({ transaction_type: v })}
            options={[
              { value: "", label: t("filters.all") },
              { value: "sale", label: t("tx.sale") },
              { value: "rent", label: t("tx.rent") },
            ]}
          />

          <Segmented
            name="f-type"
            legend={t("filters.type")}
            value={filters.property_type}
            onChange={(v) => update({ property_type: v })}
            options={[
              { value: "", label: t("filters.all") },
              { value: "apartment", label: t("ptype.apartment") },
              { value: "building", label: t("ptype.building") },
              { value: "land", label: t("ptype.land") },
            ]}
          />

          {filters.transaction_type === "rent" && (
            <>
              <Segmented
                name="f-period"
                legend={t("filters.period")}
                value={filters.rental_period}
                onChange={(v) => update({ rental_period: v })}
                options={[
                  { value: "", label: t("filters.all") },
                  { value: "daily", label: t("period.daily") },
                  { value: "monthly", label: t("period.monthly") },
                ]}
              />
              <Segmented
                name="f-scope"
                legend={t("filters.scope")}
                value={filters.scope}
                onChange={(v) => update({ scope: v })}
                options={[
                  { value: "", label: t("filters.all") },
                  { value: "whole", label: t("scope.whole") },
                  { value: "bed", label: t("scope.bed") },
                ]}
              />
            </>
          )}

          <div className="field">
            <label htmlFor="f-city">{t("filters.city")}</label>
            <input id="f-city" value={filters.city} onChange={(e) => update({ city: e.target.value })} />
          </div>

          <div className="field-pair">
            <div className="field">
              <label htmlFor="f-min">{t("filters.minPrice")}</label>
              <input id="f-min" type="number" min={0} inputMode="numeric" value={filters.min_price} onChange={(e) => update({ min_price: e.target.value })} />
            </div>
            <div className="field">
              <label htmlFor="f-max">{t("filters.maxPrice")}</label>
              <input id="f-max" type="number" min={0} inputMode="numeric" value={filters.max_price} onChange={(e) => update({ max_price: e.target.value })} />
            </div>
          </div>

          <fieldset className="seg">
            <legend>{t("filters.amenities")}</legend>
            <div className="chips">
              {FILTER_AMENITIES.map((a) => {
                const on = filters.amenities.includes(a);
                return (
                  <label key={a} className={`chip${on ? " on" : ""}`}>
                    <input
                      type="checkbox"
                      checked={on}
                      onChange={() =>
                        update({ amenities: on ? filters.amenities.filter((x) => x !== a) : [...filters.amenities, a] })
                      }
                    />
                    {amenityLabel(a, t)}
                  </label>
                );
              })}
            </div>
          </fieldset>

          <button type="button" className="btn ghost sm" onClick={clear} disabled={applied.length === 0}>
            {t("filters.clear")}
          </button>
        </div>
      </aside>

      <section aria-live="polite" className="results">
        <div className="results-head">
          <p>{data ? t("browse.count", { n: data.total }) : t("common.loading")}</p>
          <div className="sort">
            <label htmlFor="f-sort">{t("filters.sort")}</label>
            <select id="f-sort" value={filters.sort} onChange={(e) => update({ sort: e.target.value as Sort })}>
              <option value="newest">{t("sort.newest")}</option>
              <option value="price_asc">{t("sort.priceAsc")}</option>
              <option value="price_desc">{t("sort.priceDesc")}</option>
            </select>
          </div>
        </div>

        {applied.length > 0 && (
          <ul className="applied">
            {applied.map((a) => (
              <li key={a.key}>
                <button type="button" onClick={a.remove} aria-label={t("filters.remove", { name: a.label })}>
                  {a.label} <Icon name="x" size={13} />
                </button>
              </li>
            ))}
          </ul>
        )}

        {failed && (
          <p className="error" role="alert">
            {t("err.load")}
          </p>
        )}

        {!data && loading && <CardSkeleton />}
        {data && data.items.length > 0 && <PropertyGrid items={data.items} dimmed={loading} />}

        {data && data.items.length === 0 && !failed && (
          <div className="empty">
            <h2>{applied.length > 0 ? t("browse.emptyTitle") : t("home.empty.title")}</h2>
            <p>{applied.length > 0 ? t("browse.emptyText") : t("home.empty.text")}</p>
            {applied.length > 0 && (
              <button type="button" className="btn ghost" onClick={clear}>
                {t("filters.clear")}
              </button>
            )}
          </div>
        )}

        {data && totalPages > 1 && (
          <nav className="pager" aria-label={t("browse.pages")}>
            <button type="button" className="btn ghost sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
              {t("browse.prev")}
            </button>
            <span>{t("browse.page", { page, total: totalPages })}</span>
            <button type="button" className="btn ghost sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
              {t("browse.next")}
            </button>
          </nav>
        )}
      </section>
    </div>
  );
}
