"use client";

import { useRef, useState, type ChangeEvent, type FormEvent, type KeyboardEvent } from "react";
import { useRouter } from "next/navigation";
import { api, ApiError } from "@/lib/api";
import { AMENITIES, CURRENCIES } from "@/lib/amenities";
import { amenityLabel } from "@/lib/format";
import { useI18n } from "@/lib/i18n-client";
import type { Property, PropertyType, RentalPeriod, Scope, TransactionType } from "@/lib/types";
import Icon from "./Icons";
import MapView from "./MapView";
import PropertyCard from "./PropertyCard";
import { useToast } from "./Toast";
import Segmented from "./Segmented";

interface FormState {
  title: string;
  property_type: PropertyType;
  transaction_type: TransactionType;
  rental_period: RentalPeriod;
  accommodation_scope: Scope;
  beds_available: string;
  description: string;
  price: string;
  currency: string;
  city: string;
  address: string;
  latitude: number | null;
  longitude: number | null;
  amenities: string[];
}

interface MediaItem {
  key: string;
  url: string;
  media_type: "image" | "video";
}

interface Pending {
  key: string;
  name: string;
  status: "uploading" | "error";
  message?: string;
}

const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;
const KNOWN = AMENITIES as readonly string[];

function initialState(p?: Property): FormState {
  return {
    title: p?.title ?? "",
    property_type: p?.property_type ?? "apartment",
    transaction_type: p?.transaction_type ?? "rent",
    rental_period: p?.rental_period ?? "monthly",
    accommodation_scope: p?.accommodation_scope ?? "whole",
    beds_available: p?.beds_available ? String(p.beds_available) : "",
    description: p?.description ?? "",
    price: p ? String(p.price) : "",
    currency: p?.currency ?? "EGP",
    city: p?.city ?? "",
    address: p?.address ?? "",
    latitude: p?.latitude ?? null,
    longitude: p?.longitude ?? null,
    amenities: p?.amenities ?? [],
  };
}

export default function PropertyForm({ property }: { property?: Property }) {
  const { t } = useI18n();
  const router = useRouter();
  const toast = useToast();
  const [f, setF] = useState<FormState>(() => initialState(property));
  const [media, setMedia] = useState<MediaItem[]>(() =>
    (property?.media ?? []).map((m) => ({ key: String(m.id), url: m.url, media_type: m.media_type })),
  );
  const [pending, setPending] = useState<Pending[]>([]);
  const [custom, setCustom] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setF((prev) => ({ ...prev, [key]: value }));

  const isRent = f.transaction_type === "rent";
  const canBed = isRent && f.property_type !== "land";
  const byBed = canBed && f.accommodation_scope === "bed";
  const priceLabel = !isRent ? t("form.priceSale") : byBed ? t("form.priceBed") : t("form.priceRent");
  const unitHint = !isRent ? "" : f.rental_period === "daily" ? t("unit.perDay") : t("unit.perMonth");
  const preview: Property = {
    id: 0,
    owner_id: 0,
    owner: { id: 0, name: "" },
    title: f.title.trim() || t("form.previewTitle"),
    property_type: f.property_type,
    transaction_type: f.transaction_type,
    rental_period: isRent ? f.rental_period : null,
    accommodation_scope: canBed ? f.accommodation_scope : "whole",
    beds_available: byBed ? Number(f.beds_available) || null : null,
    description: "",
    price: Number(f.price) || 0,
    currency: f.currency,
    city: f.city.trim() || t("form.previewCity"),
    address: null,
    latitude: null,
    longitude: null,
    amenities: [],
    is_active: true,
    created_at: "",
    media: media.map((m, i) => ({ id: i, url: m.url, media_type: m.media_type, sort_order: i })),
  };
  const customAmenities = f.amenities.filter((a) => !KNOWN.includes(a));

  const toggleAmenity = (a: string) =>
    set("amenities", f.amenities.includes(a) ? f.amenities.filter((x) => x !== a) : [...f.amenities, a]);

  function addCustom() {
    const value = custom.trim();
    if (value && !f.amenities.includes(value)) set("amenities", [...f.amenities, value]);
    setCustom("");
  }

  function onCustomKey(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      e.preventDefault();
      addCustom();
    }
  }

  async function onFiles(e: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    e.target.value = "";
    for (const file of files) {
      const key = uid();
      setPending((list) => [...list, { key, name: file.name, status: "uploading" }]);
      try {
        const body = new FormData();
        body.append("file", file);
        const res = await api<{ url: string; media_type: "image" | "video" }>("/api/media/upload", { method: "POST", body });
        setMedia((list) => [...list, { key, url: res.url, media_type: res.media_type }]);
        setPending((list) => list.filter((p) => p.key !== key));
      } catch (err) {
        const message = err instanceof ApiError ? err.message : t("err.generic");
        setPending((list) => list.map((p) => (p.key === key ? { ...p, status: "error", message } : p)));
      }
    }
  }

  const removeMedia = (key: string) => setMedia((list) => list.filter((m) => m.key !== key));
  const makeCover = (key: string) =>
    setMedia((list) => {
      const item = list.find((m) => m.key === key);
      return item ? [item, ...list.filter((m) => m.key !== key)] : list;
    });

  function locateMe() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setF((prev) => ({ ...prev, latitude: pos.coords.latitude, longitude: pos.coords.longitude })),
      () => setError(t("form.errLocate")),
    );
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    const price = Number(f.price);
    if (!(price > 0)) return setError(t("form.errPrice"));
    if (byBed && !(Number(f.beds_available) >= 1)) return setError(t("form.errBeds"));
    if (f.latitude == null || f.longitude == null) return setError(t("form.errMap"));
    if (pending.some((p) => p.status === "uploading")) return setError(t("form.errUploading"));

    const payload = {
      title: f.title.trim(),
      property_type: f.property_type,
      transaction_type: f.transaction_type,
      rental_period: isRent ? f.rental_period : null,
      accommodation_scope: canBed ? f.accommodation_scope : "whole",
      beds_available: byBed ? Number(f.beds_available) : null,
      description: f.description.trim(),
      price,
      currency: f.currency,
      city: f.city.trim(),
      address: f.address.trim() || null,
      latitude: f.latitude,
      longitude: f.longitude,
      amenities: f.amenities,
      media: media.map((m) => ({ url: m.url, media_type: m.media_type })),
    };

    setSaving(true);
    try {
      if (property) {
        await api(`/api/properties/${property.id}`, { method: "PUT", json: payload });
      } else {
        await api("/api/properties", { method: "POST", json: payload });
      }
      toast.show(property ? t("toast.updated") : t("toast.published"));
      router.push("/owner");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : t("err.generic"));
      setSaving(false);
    }
  }

  return (
    <div className="form-layout">
    <form className="property-form" onSubmit={onSubmit}>
      <section className="form-section">
        <h2>{t("form.basics")}</h2>

        <div className="field">
          <label htmlFor="p-title">{t("form.title")}</label>
          <input id="p-title" value={f.title} onChange={(e) => set("title", e.target.value)} minLength={3} maxLength={200} required />
        </div>

        <Segmented
          name="p-type"
          legend={t("form.type")}
          value={f.property_type}
          onChange={(v) =>
            setF((prev) => ({ ...prev, property_type: v, accommodation_scope: v === "land" ? "whole" : prev.accommodation_scope }))
          }
          options={[
            { value: "apartment", label: t("ptype.apartment") },
            { value: "building", label: t("ptype.building") },
            { value: "land", label: t("ptype.land") },
          ]}
        />

        <Segmented
          name="p-tx"
          legend={t("form.transaction")}
          value={f.transaction_type}
          onChange={(v) => set("transaction_type", v)}
          options={[
            { value: "sale", label: t("tx.sale") },
            { value: "rent", label: t("tx.rent") },
          ]}
        />

        {isRent && (
          <Segmented
            name="p-period"
            legend={t("form.period")}
            value={f.rental_period}
            onChange={(v) => set("rental_period", v)}
            options={[
              { value: "monthly", label: t("period.monthly") },
              { value: "daily", label: t("period.daily") },
            ]}
          />
        )}

        {canBed && (
          <Segmented
            name="p-scope"
            legend={t("form.scope")}
            value={f.accommodation_scope}
            onChange={(v) => set("accommodation_scope", v)}
            options={[
              { value: "whole", label: t("scope.whole") },
              { value: "bed", label: t("scope.bed") },
            ]}
          />
        )}

        {byBed && (
          <div className="field narrow">
            <label htmlFor="p-beds">{t("form.beds")}</label>
            <input id="p-beds" type="number" min={1} max={500} inputMode="numeric" value={f.beds_available} onChange={(e) => set("beds_available", e.target.value)} required />
            <span className="hint">{t("form.bedsHint")}</span>
          </div>
        )}
      </section>

      <section className="form-section">
        <h2>{t("form.pricing")}</h2>
        <div className="field-pair">
          <div className="field">
            <label htmlFor="p-price">
              {priceLabel} {unitHint && <span className="hint">({unitHint})</span>}
            </label>
            <input id="p-price" type="number" min={1} step="any" inputMode="decimal" value={f.price} onChange={(e) => set("price", e.target.value)} required />
          </div>
          <div className="field">
            <label htmlFor="p-currency">{t("form.currency")}</label>
            <select id="p-currency" value={f.currency} onChange={(e) => set("currency", e.target.value)}>
              {CURRENCIES.map((c) => (
                <option key={c} value={c}>
                  {t(`cur.${c}`)}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      <section className="form-section">
        <h2>{t("form.details")}</h2>
        <div className="field">
          <label htmlFor="p-desc">{t("form.description")}</label>
          <textarea id="p-desc" rows={7} value={f.description} onChange={(e) => set("description", e.target.value)} maxLength={5000} required />
          <span className="hint field-note"><span>{t("form.descriptionHint")}</span><span>{t("form.chars", { n: f.description.length })}</span></span>
        </div>

        <fieldset className="seg">
          <legend>{t("form.amenities")}</legend>
          <div className="chips">
            {AMENITIES.map((a) => {
              const on = f.amenities.includes(a);
              return (
                <label key={a} className={`chip${on ? " on" : ""}`}>
                  <input type="checkbox" checked={on} onChange={() => toggleAmenity(a)} />
                  {amenityLabel(a, t)}
                </label>
              );
            })}
            {customAmenities.map((a) => (
              <span key={a} className="chip on removable">
                {a}
                <button type="button" onClick={() => toggleAmenity(a)} aria-label={t("form.removeAmenity", { name: a })}>
                  <Icon name="x" size={14} />
                </button>
              </span>
            ))}
          </div>
          <div className="inline-add">
            <input value={custom} onChange={(e) => setCustom(e.target.value)} onKeyDown={onCustomKey} maxLength={60} placeholder={t("form.customAmenity")} aria-label={t("form.customAmenity")} />
            <button type="button" className="btn ghost sm" onClick={addCustom}>
              <Icon name="plus" size={16} /> {t("form.add")}
            </button>
          </div>
        </fieldset>
      </section>

      <section className="form-section">
        <h2>{t("form.location")}</h2>
        <div className="field-pair">
          <div className="field">
            <label htmlFor="p-city">{t("form.city")}</label>
            <input id="p-city" value={f.city} onChange={(e) => set("city", e.target.value)} minLength={2} maxLength={80} required />
          </div>
          <div className="field">
            <label htmlFor="p-address">{t("form.address")}</label>
            <input id="p-address" value={f.address} onChange={(e) => set("address", e.target.value)} maxLength={255} />
          </div>
        </div>
        <p className="hint">{t("form.mapHint")}</p>
        <MapView
          lat={f.latitude}
          lng={f.longitude}
          editable
          height={360}
          label={t("form.location")}
          onChange={(latitude, longitude) => setF((prev) => ({ ...prev, latitude, longitude }))}
        />
        <div className="btn-row">
          <button type="button" className="btn ghost sm" onClick={locateMe}>
            <Icon name="locate" size={16} /> {t("form.useMyLocation")}
          </button>
          {f.latitude != null && f.longitude != null && (
            <span className="hint" dir="ltr">
              {f.latitude.toFixed(5)}, {f.longitude.toFixed(5)}
            </span>
          )}
        </div>
      </section>

      <section className="form-section">
        <h2>{t("form.media")}</h2>
        <p className="hint">{t("form.mediaHint")}</p>

        <input ref={fileInput} type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" multiple hidden onChange={onFiles} />
        <button type="button" className="btn ghost" onClick={() => fileInput.current?.click()}>
          <Icon name="upload" /> {t("form.upload")}
        </button>

        {(media.length > 0 || pending.length > 0) && (
          <ul className="media-grid">
            {media.map((m, i) => (
              <li key={m.key}>
                {m.media_type === "image" ? <img src={m.url} alt="" /> : <video src={m.url} muted playsInline preload="metadata" />}
                {i === 0 && <span className="cover-tag">{t("form.cover")}</span>}
                <div className="media-actions">
                  {i !== 0 && m.media_type === "image" && (
                    <button type="button" onClick={() => makeCover(m.key)}>
                      {t("form.makeCover")}
                    </button>
                  )}
                  <button type="button" onClick={() => removeMedia(m.key)} aria-label={t("form.remove")}>
                    <Icon name="trash" size={16} />
                  </button>
                </div>
              </li>
            ))}
            {pending.map((p) => (
              <li key={p.key} className={`pending ${p.status}`}>
                <span>{p.name}</span>
                <span role={p.status === "error" ? "alert" : undefined}>
                  {p.status === "uploading" ? t("form.uploading") : p.message}
                </span>
                {p.status === "error" && (
                  <button type="button" onClick={() => setPending((list) => list.filter((x) => x.key !== p.key))}>
                    {t("form.dismiss")}
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}

      <div className="btn-row form-actions">
        <button type="submit" className="btn" disabled={saving}>
          {saving ? t("common.saving") : property ? t("form.saveChanges") : t("form.publish")}
        </button>
        <button type="button" className="btn ghost" onClick={() => router.push("/owner")}>
          {t("common.cancel")}
        </button>
      </div>
    </form>

    <aside className="form-preview">
      <h2>{t("form.preview")}</h2>
      <p className="hint">{t("form.previewHint")}</p>
      <div className="preview-lock" inert>
        <PropertyCard p={preview} />
      </div>
    </aside>
    </div>
  );
}
