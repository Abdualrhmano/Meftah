"use client";

import Link from "next/link";
import { useI18n } from "@/lib/i18n-client";
import { coverOf, priceParts } from "@/lib/format";
import type { Property } from "@/lib/types";
import { FacadeArt } from "./Art";
import Icon from "./Icons";

export default function OwnerRows({
  items,
  onToggle,
  onDelete,
}: {
  items: Property[];
  onToggle: (p: Property) => void;
  onDelete: (p: Property) => void;
}) {
  const { t, locale } = useI18n();
  return (
    <ul className="rows">
      {items.map((p) => {
        const cover = coverOf(p);
        const price = priceParts(p, t, locale);
        return (
          <li key={p.id} className={p.is_active ? undefined : "is-hidden"}>
            <div className="row-thumb">
              {cover ? <img src={cover} alt="" loading="lazy" /> : <FacadeArt kind={p.accommodation_scope === "bed" ? "bed" : p.property_type} />}
            </div>
            <div className="row-main">
              <h2>{p.is_active ? <Link href={`/properties/${p.id}`}>{p.title}</Link> : p.title}</h2>
              <p className="meta">
                <Icon name="pin" size={15} /> {p.city}
              </p>
              <p className="row-tags">
                <span className={`tag inline tag-${p.transaction_type}`}>{t(`tx.${p.transaction_type}`)}</span>
                <span className="tag inline tag-plain">{t(`ptype.${p.property_type}`)}</span>
                {!p.is_active && <span className="tag inline tag-hidden">{t("owner.hidden")}</span>}
              </p>
            </div>
            <p className="price row-price">
              <strong>{price.amount}</strong>
              {price.unit && <span>{price.unit}</span>}
            </p>
            <div className="row-actions">
              <Link href={`/owner/properties/${p.id}/edit`} className="btn ghost sm">
                <Icon name="edit" size={16} /> {t("owner.edit")}
              </Link>
              <button type="button" className="btn ghost sm" onClick={() => onToggle(p)}>
                <Icon name={p.is_active ? "eyeoff" : "eye"} size={16} /> {p.is_active ? t("owner.hide") : t("owner.show")}
              </button>
              <button type="button" className="btn ghost sm danger" onClick={() => onDelete(p)}>
                <Icon name="trash" size={16} /> {t("owner.delete")}
              </button>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
