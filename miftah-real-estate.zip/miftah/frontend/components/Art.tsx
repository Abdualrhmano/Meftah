import type { PropertyType } from "@/lib/types";

/** Home page illustration: a building elevation where one window is lit. */
export function HeroArt() {
  const towerWindows = [];
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 4; col++) {
      towerWindows.push({ x: 58 + col * 40, y: 80 + row * 42, lit: col === 1 && row === 3 });
    }
  }
  const lowWindows = [];
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 2; col++) {
      lowWindows.push({ x: 238 + col * 40, y: 210 + row * 44 });
    }
  }
  return (
    <svg viewBox="0 0 360 460" className="hero-art" aria-hidden="true">
      <rect x="0" y="430" width="360" height="2" fill="var(--ink)" />
      <rect x="40" y="60" width="170" height="370" fill="var(--ink)" />
      {towerWindows.map((w) => (
        <rect key={`a${w.x}-${w.y}`} x={w.x} y={w.y} width="28" height="34" className={w.lit ? "lit" : undefined} fill={w.lit ? "var(--brass)" : "var(--window)"} />
      ))}
      <rect x="220" y="190" width="100" height="240" fill="var(--ink-2)" />
      {lowWindows.map((w) => (
        <rect key={`b${w.x}-${w.y}`} x={w.x} y={w.y} width="26" height="32" fill="var(--window)" />
      ))}
    </svg>
  );
}

/** Placeholder shown on listings that have no photo yet. */
export function FacadeArt({ kind }: { kind: PropertyType | "bed" }) {
  if (kind === "bed") {
    return (
      <svg viewBox="0 0 200 150" preserveAspectRatio="xMidYMid slice" className="facade" aria-hidden="true">
        <rect width="200" height="150" fill="var(--sky)" />
        <rect x="0" y="118" width="200" height="32" fill="#BFD3CB" />
        <rect x="122" y="20" width="52" height="46" fill="var(--window)" />
        <rect x="147" y="20" width="2" height="46" fill="var(--sky)" />
        <rect x="122" y="42" width="52" height="2" fill="var(--sky)" />
        <rect x="38" y="62" width="8" height="60" fill="var(--ink)" />
        <rect x="38" y="98" width="124" height="20" fill="var(--ink)" />
        <rect x="154" y="98" width="8" height="32" fill="var(--ink)" />
        <rect x="38" y="118" width="8" height="12" fill="var(--ink)" />
        <rect x="46" y="86" width="108" height="14" fill="#fff" />
        <rect x="52" y="78" width="28" height="10" rx="3" fill="var(--brass)" />
      </svg>
    );
  }
  if (kind === "land") {
    return (
      <svg viewBox="0 0 200 150" preserveAspectRatio="xMidYMid slice" className="facade" aria-hidden="true">
        <rect width="200" height="150" fill="var(--sky)" />
        <polygon points="0,105 60,88 130,100 200,82 200,150 0,150" fill="#BFD3CB" />
        <polygon points="0,125 80,110 200,120 200,150 0,150" fill="#A9C4BA" />
        <rect x="98" y="70" width="3" height="44" fill="var(--ink)" />
        <rect x="101" y="70" width="26" height="14" fill="var(--brass)" />
      </svg>
    );
  }

  const building = kind === "building";
  const cols = building ? 4 : 3;
  const rows = building ? 6 : 4;
  const cw = building ? 18 : 22;
  const ch = building ? 20 : 24;
  const width = cols * cw + 12;
  const height = rows * ch + 12;
  const left = (200 - width) / 2;
  const top = 150 - height - 8;

  const windows = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      windows.push({ x: left + 6 + c * cw + 4, y: top + 6 + r * ch + 4, lit: r === 1 && c === 1 });
    }
  }

  return (
    <svg viewBox="0 0 200 150" preserveAspectRatio="xMidYMax slice" className="facade" aria-hidden="true">
      <rect width="200" height="150" fill="var(--sky)" />
      <rect x="0" y="142" width="200" height="8" fill="#BFD3CB" />
      <rect x={left} y={top} width={width} height={height} fill="var(--ink)" />
      {windows.map((w) => (
        <rect key={`${w.x}-${w.y}`} x={w.x} y={w.y} width={cw - 8} height={ch - 8} fill={w.lit ? "var(--brass)" : "var(--window)"} />
      ))}
    </svg>
  );
}
