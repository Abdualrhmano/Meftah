"use client";

import { useRef, useState, type FormEvent } from "react";
import { ApiError, api } from "@/lib/api";
import { useI18n } from "@/lib/i18n-client";
import Icon from "./Icons";

export default function DeleteAccountDialog({ onConfirmed }: { onConfirmed: () => void }) {
  const { t } = useI18n();
  const dialog = useRef<HTMLDialogElement>(null);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function open() {
    setPassword("");
    setError(null);
    dialog.current?.showModal();
  }

  async function confirm(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/auth/me", { method: "DELETE", json: { password } });
      dialog.current?.close();
      onConfirmed();
    } catch (err) {
      setError(err instanceof ApiError && err.status === 401 ? t("account.wrongPassword") : t("err.generic"));
      setBusy(false);
    }
  }

  return (
    <>
      <button type="button" className="btn danger" onClick={open}>
        <Icon name="trash" size={16} /> {t("account.deleteAccount")}
      </button>
      <dialog ref={dialog} className="confirm-dialog" onClose={() => setBusy(false)}>
        <form onSubmit={confirm}>
          <h2>{t("account.deleteAccount")}</h2>
          <p>{t("account.deleteWarning")}</p>
          <div className="field">
            <label htmlFor="delete-password">{t("account.confirmWithPassword")}</label>
            <input
              id="delete-password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              dir="ltr"
            />
          </div>
          {error && <p className="error" role="alert">{error}</p>}
          <div className="btn-row">
            <button type="submit" className="btn danger" disabled={busy || !password}>
              {busy ? t("common.loading") : t("account.deleteConfirm")}
            </button>
            <button type="button" className="btn ghost" onClick={() => dialog.current?.close()} disabled={busy}>
              {t("common.cancel")}
            </button>
          </div>
        </form>
      </dialog>
    </>
  );
}
