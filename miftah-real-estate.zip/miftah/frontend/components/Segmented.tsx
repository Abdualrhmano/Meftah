"use client";

interface Option<T extends string> {
  value: T;
  label: string;
}

/** Accessible single-choice control built on radio inputs. */
export default function Segmented<T extends string>({
  name,
  legend,
  value,
  options,
  onChange,
}: {
  name: string;
  legend?: string;
  value: T;
  options: Option<T>[];
  onChange: (value: T) => void;
}) {
  return (
    <fieldset className="seg">
      {legend && <legend>{legend}</legend>}
      <div className="seg-row">
        {options.map((option) => (
          <label key={option.value} className={value === option.value ? "on" : undefined}>
            <input
              type="radio"
              name={name}
              value={option.value}
              checked={value === option.value}
              onChange={() => onChange(option.value)}
            />
            {option.label}
          </label>
        ))}
      </div>
    </fieldset>
  );
}
