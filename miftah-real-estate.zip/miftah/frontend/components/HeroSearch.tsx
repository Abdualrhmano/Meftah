"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { useI18n } from "@/lib/i18n-client";
import type { PropertyType, TransactionType } from "@/lib/types";
import Segmented from "./Segmented";

export default function HeroSearch() {
  const { t } = useI18n();
  const router = useRouter();
  const [tx, setTx] = useState<TransactionType>("rent");
  const [type, setType] = useState<"" | PropertyType>("");
  const [q, setQ] = useState("");

  function submit(e: FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams({ transaction_type: tx });
    if (type) params.set("property_type", type);
    if (q.trim()) params.set("q", q.trim());
    router.push(`/properties?${params}`);
  }

  return (
    <form className="hero-search" onSubmit={submit}>
      <Segmented
        name="hero-tx"
        value={tx}
        onChange={setTx}
        options={[
          { value: "rent", label: t("tx.rent") },
          { value: "sale", label: t("tx.sale") },
        ]}
      />
      <div className="hero-search-row">
        <div className="field">
          <label htmlFor="hero-q">{t("hero.where")}</label>
          <input id="hero-q" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("hero.wherePlaceholder")} />
        </div>
        <div className="field">
          <label htmlFor="hero-type">{t("hero.what")}</label>
          <select id="hero-type" value={type} onChange={(e) => setType(e.target.value as "" | PropertyType)}>
            <option value="">{t("filters.all")}</option>
            <option value="apartment">{t("ptype.apartment")}</option>
            <option value="building">{t("ptype.building")}</option>
            <option value="land">{t("ptype.land")}</option>
          </select>
        </div>
        <button type="submit" className="btn">{t("hero.search")}</button>
      </div>
    </form>
  );
}
