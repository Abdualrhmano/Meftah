"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n-client";
import type { Conversation, Property } from "@/lib/types";

export default function ContactOwner({ property }: { property: Property }) {
  const { t } = useI18n();
  const { user, loading } = useAuth();
  const router = useRouter();
  const [body, setBody] = useState(() => t("contact.defaultMessage", { title: property.title }));
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(false);

  if (loading) return null;

  if (!user) {
    const next = encodeURIComponent(`/properties/${property.id}`);
    return (
      <div className="contact-box">
        <h2>{t("contact.title")}</h2>
        <p>{t("contact.loginPrompt")}</p>
        <div className="btn-row">
          <Link href={`/login?next=${next}`} className="btn">{t("nav.login")}</Link>
          <Link href={`/register?next=${next}`} className="btn ghost">{t("nav.register")}</Link>
        </div>
      </div>
    );
  }

  if (user.role === "owner") {
    return (
      <div className="contact-box">
        <h2>{t("contact.title")}</h2>
        {user.id === property.owner_id ? (
          <>
            <p>{t("contact.yourListing")}</p>
            <Link href={`/owner/properties/${property.id}/edit`} className="btn">{t("owner.edit")}</Link>
          </>
        ) : (
          <p>{t("contact.ownerAccount")}</p>
        )}
      </div>
    );
  }

  async function send(e: FormEvent) {
    e.preventDefault();
    if (!body.trim()) return;
    setSending(true);
    setError(false);
    try {
      const conversation = await api<Conversation>("/api/conversations", {
        method: "POST",
        json: { property_id: property.id, body: body.trim() },
      });
      router.push(`/messages?c=${conversation.id}`);
    } catch {
      setError(true);
      setSending(false);
    }
  }

  return (
    <form className="contact-box" onSubmit={send}>
      <h2>{t("contact.title")}</h2>
      <p className="hint">{t("contact.hint", { name: property.owner.name })}</p>
      <div className="field">
        <label htmlFor="contact-body">{t("contact.message")}</label>
        <textarea id="contact-body" value={body} onChange={(e) => setBody(e.target.value)} maxLength={4000} rows={5} required />
      </div>
      {error && <p className="error" role="alert">{t("err.generic")}</p>}
      <button type="submit" className="btn" disabled={sending}>
        {sending ? t("common.sending") : t("contact.send")}
      </button>
    </form>
  );
}
