"use client";

import type { ReactNode } from "react";
import { useI18n } from "@/lib/i18n-client";
import { HeroArt } from "./Art";

/** Two-column frame for the login and register screens. */
export default function AuthShell({ mode, children }: { mode: "login" | "register"; children: ReactNode }) {
  const { t } = useI18n();
  return (
    <div className="container auth-layout">
      <div className="auth-main">{children}</div>
      <aside className="auth-side" aria-hidden="true">
        <HeroArt />
        <h2>{t(`auth.side.${mode}`)}</h2>
        <p>{t(`auth.side.${mode}Text`)}</p>
      </aside>
    </div>
  );
}
