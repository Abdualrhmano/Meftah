"use client";

import Link from "next/link";
import { useI18n } from "@/lib/i18n-client";
import { coverOf, priceParts } from "@/lib/format";
import type { Property } from "@/lib/types";
import { FacadeArt } from "./Art";
import Icon from "./Icons";

export default function PropertyCard({ p }: { p: Property }) {
  const { t, locale } = useI18n();
  const cover = coverOf(p);
  const price = priceParts(p, t, locale);
  const href = `/properties/${p.id}`;
  const art = p.accommodation_scope === "bed" ? "bed" : p.property_type;

  return (
    <article className="card">
      <Link href={href} className="card-media" tabIndex={-1} aria-hidden="true">
        {cover ? <img src={cover} alt="" loading="lazy" /> : <FacadeArt kind={art} />}
        <span className={`tag tag-${p.transaction_type}`}>{t(`tx.${p.transaction_type}`)}</span>
        {p.media.length > 1 && <span className="media-count">{p.media.length}</span>}
      </Link>
      <div className="card-body">
        <p className="price">
          <strong>{price.amount}</strong>
          {price.unit && <span>{price.unit}</span>}
        </p>
        <h3>
          <Link href={href}>{p.title}</Link>
        </h3>
        <p className="meta">
          <Icon name="pin" size={15} /> {p.city}
        </p>
        <p className="facts">
          <span>{t(`ptype.${p.property_type}`)}</span>
          {p.accommodation_scope === "bed" && p.beds_available && (
            <span>
              <Icon name="bed" size={15} /> {t("card.bedsAvailable", { n: p.beds_available })}
            </span>
          )}
        </p>
      </div>
    </article>
  );
}

export function PropertyGrid({ items, dimmed }: { items: Property[]; dimmed?: boolean }) {
  return (
    <div className={`grid${dimmed ? " is-loading" : ""}`}>
      {items.map((p) => (
        <PropertyCard key={p.id} p={p} />
      ))}
    </div>
  );
}

export function CardSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid" aria-hidden="true">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="card skeleton">
          <div className="card-media" />
          <div className="card-body">
            <span className="line w40" />
            <span className="line w80" />
            <span className="line w55" />
          </div>
        </div>
      ))}
    </div>
  );
}
