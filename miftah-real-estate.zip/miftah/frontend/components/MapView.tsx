"use client";

import { useEffect, useRef } from "react";
import type { Map as LeafletMap, Marker } from "leaflet";

type Leaflet = typeof import("leaflet");

interface Props {
  lat: number | null;
  lng: number | null;
  editable?: boolean;
  height?: number;
  onChange?: (lat: number, lng: number) => void;
  label?: string;
}

const DEFAULT_CENTER: [number, number] = [30.0444, 31.2357]; // Cairo

/** OpenStreetMap view. In `editable` mode the owner clicks or drags the pin to set the exact location. */
export default function MapView({ lat, lng, editable = false, height = 320, onChange, label }: Props) {
  const container = useRef<HTMLDivElement>(null);
  const leaflet = useRef<Leaflet | null>(null);
  const map = useRef<LeafletMap | null>(null);
  const marker = useRef<Marker | null>(null);
  const latest = useRef({ lat, lng, editable, onChange });
  latest.current = { lat, lng, editable, onChange };

  function syncMarker(pan: boolean) {
    const L = leaflet.current;
    const m = map.current;
    const { lat: la, lng: ln, editable: canEdit } = latest.current;
    if (!L || !m || la == null || ln == null) return;

    if (marker.current) {
      marker.current.setLatLng([la, ln]);
    } else {
      const icon = L.divIcon({ className: "pin", html: "<span></span>", iconSize: [28, 28], iconAnchor: [14, 34] });
      const created = L.marker([la, ln], { icon, draggable: canEdit, keyboard: canEdit }).addTo(m);
      created.on("dragend", () => {
        const p = created.getLatLng();
        latest.current.onChange?.(p.lat, p.lng);
      });
      marker.current = created;
    }
    if (pan) m.setView([la, ln], Math.max(m.getZoom(), 15));
  }

  useEffect(() => {
    let cancelled = false;

    (async () => {
      const L = (await import("leaflet")).default as unknown as Leaflet;
      if (cancelled || !container.current || map.current) return;
      leaflet.current = L;

      const { lat: la, lng: ln, editable: canEdit } = latest.current;
      const hasPoint = la != null && ln != null;
      const instance = L.map(container.current, { scrollWheelZoom: canEdit }).setView(
        hasPoint ? [la as number, ln as number] : DEFAULT_CENTER,
        hasPoint ? 15 : 11,
      );
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      }).addTo(instance);

      if (canEdit) {
        instance.on("click", (e) => latest.current.onChange?.(e.latlng.lat, e.latlng.lng));
      }
      map.current = instance;
      syncMarker(false);
    })();

    return () => {
      cancelled = true;
      map.current?.remove();
      map.current = null;
      marker.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    syncMarker(editable);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lat, lng]);

  return <div ref={container} className="map" style={{ height }} role="region" aria-label={label} />;
}
