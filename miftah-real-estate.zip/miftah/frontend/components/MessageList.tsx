"use client";

import { Fragment } from "react";
import { formatDate, formatDateTime } from "@/lib/format";
import { useI18n } from "@/lib/i18n-client";
import type { Message } from "@/lib/types";

const dayKey = (iso: string) => new Date(iso).toDateString();

/** Chat bubbles grouped by day. */
export default function MessageList({ messages, me }: { messages: Message[]; me: number }) {
  const { locale } = useI18n();
  return (
    <>
      {messages.map((m, i) => (
        <Fragment key={m.id}>
          {(i === 0 || dayKey(messages[i - 1].created_at) !== dayKey(m.created_at)) && (
            <p className="day-sep">
              <span>{formatDate(m.created_at, locale)}</span>
            </p>
          )}
          <div className={`bubble ${m.sender_id === me ? "mine" : "theirs"}`}>
            <p>{m.body}</p>
            <time dateTime={m.created_at}>{formatDateTime(m.created_at, locale)}</time>
          </div>
        </Fragment>
      ))}
    </>
  );
}
