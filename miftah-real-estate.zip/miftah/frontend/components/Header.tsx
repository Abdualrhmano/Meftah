"use client";

import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { api } from "@/lib/api";
import { homeFor, useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n-client";
import Icon from "./Icons";

export function BrandMark() {
  return (
    <svg width="26" height="26" viewBox="0 0 26 26" aria-hidden="true">
      <rect x="1" y="1" width="11" height="11" fill="var(--ink)" />
      <rect x="14" y="1" width="11" height="11" fill="var(--ink)" />
      <rect x="1" y="14" width="11" height="11" fill="var(--ink)" />
      <rect x="14" y="14" width="11" height="11" fill="var(--brass)" />
    </svg>
  );
}

export default function Header() {
  const { t, locale, setLocale } = useI18n();
  const { user, loading, logout } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(0);

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    if (!user) {
      setUnread(0);
      return;
    }
    let cancelled = false;
    const load = () =>
      api<{ count: number }>("/api/conversations/unread-count")
        .then((r) => !cancelled && setUnread(r.count))
        .catch(() => undefined);
    load();
    const timer = setInterval(load, 30000);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [user, pathname]);

  const link = (href: string, label: string, extra?: ReactNode) => (
    <Link href={href} aria-current={pathname === href || pathname.startsWith(href + "/") ? "page" : undefined}>
      {label}
      {extra}
    </Link>
  );

  return (
    <header className="site-header">
      <div className="container header-row">
        <Link href="/" className="brand">
          <BrandMark />
          <span>{t("brand")}</span>
        </Link>

        <button
          type="button"
          className="menu-toggle"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-controls="site-nav"
          aria-label={t("nav.menu")}
        >
          <Icon name={open ? "x" : "menu"} size={22} />
        </button>

        <nav id="site-nav" className={`site-nav${open ? " open" : ""}`} aria-label={t("nav.main")}>
          {link("/properties", t("nav.browse"))}
          {user && link(homeFor(user.role), user.role === "owner" ? t("nav.ownerDashboard") : t("nav.clientDashboard"))}
          {user?.role === "owner" && link("/owner/properties/new", t("nav.addProperty"))}
          {user && link("/messages", t("nav.messages"), unread > 0 && <span className="badge" aria-label={t("nav.unread", { n: unread })}>{unread}</span>)}

          <span className="nav-spacer" />

          <button type="button" className="link-btn" onClick={() => setLocale(locale === "ar" ? "en" : "ar")} lang={locale === "ar" ? "en" : "ar"}>
            <Icon name="globe" size={16} /> {locale === "ar" ? "English" : "العربية"}
          </button>

          {!user && (
            <span className={`nav-auth${loading ? " pending" : ""}`} aria-hidden={loading || undefined}>
              <Link href="/login" className="btn ghost sm" tabIndex={loading ? -1 : undefined}>{t("nav.login")}</Link>
              <Link href="/register" className="btn sm" tabIndex={loading ? -1 : undefined}>{t("nav.register")}</Link>
            </span>
          )}
          {user && (
            <>
              <Link href="/account" className="user-name" aria-label={t("nav.account")}>
                <span className="avatar" aria-hidden="true">{Array.from(user.name.trim())[0] ?? "?"}</span>
                {user.name}
              </Link>
              <button
                type="button"
                className="btn ghost sm"
                onClick={() => {
                  logout();
                  router.push("/");
                }}
              >
                {t("nav.logout")}
              </button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
