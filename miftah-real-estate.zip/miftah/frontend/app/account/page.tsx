"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import DeleteAccountDialog from "@/components/DeleteAccountDialog";
import PasswordField from "@/components/PasswordField";
import RequireRole from "@/components/RequireRole";
import { useToast } from "@/components/Toast";
import { ApiError, api } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n-client";

export default function AccountPage() {
  return (
    <RequireRole>
      <Account />
    </RequireRole>
  );
}

function Account() {
  const { t } = useI18n();
  const { user, refresh, logout } = useAuth();
  const toast = useToast();
  const router = useRouter();

  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [savingPassword, setSavingPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);

  const [resending, setResending] = useState(false);

  if (!user) return null;

  async function resendVerification() {
    setResending(true);
    try {
      await api("/api/auth/resend-verification", { method: "POST" });
      toast.show(t("toast.verificationSent"));
    } catch {
      toast.show(t("err.generic"), "error");
    } finally {
      setResending(false);
    }
  }

  async function saveProfile(e: FormEvent) {
    e.preventDefault();
    setSavingProfile(true);
    setProfileError(null);
    try {
      await api("/api/auth/me", { method: "PATCH", json: { name, phone: phone.trim() || undefined } });
      await refresh();
      toast.show(t("toast.profileUpdated"));
    } catch (err) {
      setProfileError(err instanceof ApiError ? err.message : t("err.generic"));
    } finally {
      setSavingProfile(false);
    }
  }

  async function savePassword(e: FormEvent) {
    e.preventDefault();
    setSavingPassword(true);
    setPasswordError(null);
    try {
      await api("/api/auth/change-password", {
        method: "POST",
        json: { current_password: currentPassword, new_password: newPassword },
      });
      setCurrentPassword("");
      setNewPassword("");
      toast.show(t("toast.passwordUpdated"));
    } catch (err) {
      setPasswordError(err instanceof ApiError && err.status === 401 ? t("account.wrongPassword") : t("err.generic"));
    } finally {
      setSavingPassword(false);
    }
  }

  function onAccountDeleted() {
    logout();
    toast.show(t("toast.accountDeleted"));
    router.replace("/");
  }

  return (
    <div className="container account-page">
      <div className="account-head">
        <h1>{t("account.title")}</h1>
        <span className={`verify-badge${user.is_verified ? " ok" : ""}`}>
          {user.is_verified ? t("account.verified") : t("account.notVerified")}
        </span>
      </div>

      {!user.is_verified && (
        <p className="verify-banner">
          {t("account.notVerified")}.{" "}
          <button type="button" className="link-btn" onClick={resendVerification} disabled={resending}>
            {resending ? t("common.sending") : t("account.resendVerification")}
          </button>
        </p>
      )}

      <section className="form-section">
        <h2>{t("account.profileTitle")}</h2>
        <form onSubmit={saveProfile}>
          <div className="field">
            <label htmlFor="acc-email">{t("auth.email")}</label>
            <input id="acc-email" value={user.email} disabled dir="ltr" />
            <span className="hint">{t("account.emailLocked")}</span>
          </div>
          <div className="field">
            <label htmlFor="acc-name">{t("auth.name")}</label>
            <input id="acc-name" value={name} onChange={(e) => setName(e.target.value)} minLength={2} maxLength={120} required />
          </div>
          <div className="field">
            <label htmlFor="acc-phone">{t("auth.phone")}</label>
            <input id="acc-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={32} dir="ltr" />
          </div>
          {profileError && <p className="error" role="alert">{profileError}</p>}
          <button type="submit" className="btn" disabled={savingProfile}>
            {savingProfile ? t("common.saving") : t("account.saveProfile")}
          </button>
        </form>
      </section>

      <section className="form-section">
        <h2>{t("account.passwordTitle")}</h2>
        <form onSubmit={savePassword}>
          <PasswordField
            id="acc-current-password"
            label={t("account.currentPassword")}
            value={currentPassword}
            onChange={setCurrentPassword}
            autoComplete="current-password"
          />
          <PasswordField
            id="acc-new-password"
            label={t("account.newPassword")}
            value={newPassword}
            onChange={setNewPassword}
            autoComplete="new-password"
            minLength={8}
            hint={t("auth.passwordHint")}
          />
          {passwordError && <p className="error" role="alert">{passwordError}</p>}
          <button type="submit" className="btn" disabled={savingPassword}>
            {savingPassword ? t("common.saving") : t("account.savePassword")}
          </button>
        </form>
      </section>

      <section className="form-section danger-zone">
        <h2>{t("account.dangerTitle")}</h2>
        <p>{t("account.dangerText")}</p>
        <DeleteAccountDialog onConfirmed={onAccountDeleted} />
      </section>
    </div>
  );
}
