"use client";

import { Suspense, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { ApiError } from "@/lib/api";
import { homeFor, safeNext, useAuth } from "@/lib/auth";
import AuthShell from "@/components/AuthShell";
import PasswordField from "@/components/PasswordField";
import { useI18n } from "@/lib/i18n-client";

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const { t } = useI18n();
  const { login } = useAuth();
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await login(email, password);
      // Role-based redirect: owners -> listing hub, clients -> property search.
      router.replace(safeNext(params.get("next"), res.user.role) ?? homeFor(res.user.role));
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) setError(t("auth.invalid"));
      else if (err instanceof ApiError && err.status === 429) setError(t("err.rateLimited"));
      else setError(t("err.generic"));
      setBusy(false);
    }
  }

  const nextParam = params.get("next");
  const registerHref = nextParam ? `/register?next=${encodeURIComponent(nextParam)}` : "/register";

  return (
    <AuthShell mode="login">
      <h1>{t("auth.loginTitle")}</h1>
      <form onSubmit={submit} className="auth-form">
        <div className="field">
          <label htmlFor="email">{t("auth.email")}</label>
          <input id="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required dir="ltr" />
        </div>
        <PasswordField
          id="password"
          label={t("auth.password")}
          value={password}
          onChange={setPassword}
          autoComplete="current-password"
        />
        <p className="forgot-link">
          <Link href="/forgot-password">{t("auth.forgotPassword")}</Link>
        </p>
        {error && <p className="error" role="alert">{error}</p>}
        <button type="submit" className="btn" disabled={busy}>
          {busy ? t("common.loading") : t("nav.login")}
        </button>
      </form>
      <p className="auth-alt">
        {t("auth.noAccount")} <Link href={registerHref}>{t("nav.register")}</Link>
      </p>
    </AuthShell>
  );
}
