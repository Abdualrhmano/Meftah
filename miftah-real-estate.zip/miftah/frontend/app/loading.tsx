import { getT } from "@/lib/i18n-server";

export default async function Loading() {
  const { t } = await getT();
  return <p className="page-loading container">{t("common.loading")}</p>;
}
