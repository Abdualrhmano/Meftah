import Link from "next/link";
import { getT } from "@/lib/i18n-server";

export default async function NotFound() {
  const { t } = await getT();
  return (
    <div className="container empty page-empty">
      <h1>{t("notfound.title")}</h1>
      <p>{t("notfound.text")}</p>
      <Link href="/" className="btn">{t("notfound.home")}</Link>
    </div>
  );
}
