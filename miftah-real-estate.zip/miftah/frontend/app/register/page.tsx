"use client";

import { Suspense, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import AuthShell from "@/components/AuthShell";
import PasswordField from "@/components/PasswordField";
import Segmented from "@/components/Segmented";
import { ApiError } from "@/lib/api";
import { homeFor, safeNext, useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n-client";
import type { Role } from "@/lib/types";

export default function RegisterPage() {
  return (
    <Suspense fallback={null}>
      <RegisterForm />
    </Suspense>
  );
}

function RegisterForm() {
  const { t } = useI18n();
  const { register } = useAuth();
  const router = useRouter();
  const params = useSearchParams();
  const [role, setRole] = useState<Role>(params.get("role") === "owner" ? "owner" : "client");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await register({ name, email, password, role, phone: phone.trim() || undefined });
      router.replace(safeNext(params.get("next"), res.user.role) ?? homeFor(res.user.role));
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) setError(t("auth.emailTaken"));
      else if (err instanceof ApiError && err.status === 422) setError(t("auth.checkFields"));
      else setError(t("err.generic"));
      setBusy(false);
    }
  }

  const nextParam = params.get("next");
  const loginHref = nextParam ? `/login?next=${encodeURIComponent(nextParam)}` : "/login";

  return (
    <AuthShell mode="register">
      <h1>{t("auth.registerTitle")}</h1>
      <form onSubmit={submit} className="auth-form">
        <Segmented
          name="role"
          legend={t("auth.iAm")}
          value={role}
          onChange={setRole}
          options={[
            { value: "client", label: t("auth.roleClient") },
            { value: "owner", label: t("auth.roleOwner") },
          ]}
        />
        <div className="field">
          <label htmlFor="name">{t("auth.name")}</label>
          <input id="name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} minLength={2} maxLength={120} required />
        </div>
        <div className="field">
          <label htmlFor="email">{t("auth.email")}</label>
          <input id="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required dir="ltr" />
        </div>
        <div className="field">
          <label htmlFor="phone">{t("auth.phone")}</label>
          <input id="phone" type="tel" autoComplete="tel" value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={32} dir="ltr" />
        </div>
        <PasswordField
          id="password"
          label={t("auth.password")}
          value={password}
          onChange={setPassword}
          autoComplete="new-password"
          minLength={8}
          hint={t("auth.passwordHint")}
        />
        {error && <p className="error" role="alert">{error}</p>}
        <button type="submit" className="btn" disabled={busy}>
          {busy ? t("common.loading") : t("auth.createAccount")}
        </button>
      </form>
      <p className="auth-alt">
        {t("auth.haveAccount")} <Link href={loginHref}>{t("nav.login")}</Link>
      </p>
    </AuthShell>
  );
}
