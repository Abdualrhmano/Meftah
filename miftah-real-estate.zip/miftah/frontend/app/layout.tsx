import type { Metadata } from "next";
import type { ReactNode } from "react";
import { IBM_Plex_Sans_Arabic, Readex_Pro } from "next/font/google";
import "leaflet/dist/leaflet.css";
import "./globals.css";
import { AuthProvider } from "@/lib/auth";
import { dictionaries } from "@/lib/dictionary";
import { I18nProvider } from "@/lib/i18n-client";
import { getLocale } from "@/lib/i18n-server";
import Footer from "@/components/Footer";
import Header from "@/components/Header";
import { ToastProvider } from "@/components/Toast";

const display = Readex_Pro({ subsets: ["arabic", "latin"], variable: "--font-display", display: "swap" });
const body = IBM_Plex_Sans_Arabic({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600"],
  variable: "--font-body",
  display: "swap",
});

export async function generateMetadata(): Promise<Metadata> {
  const dict = dictionaries[await getLocale()];
  return {
    title: { default: dict["meta.title"], template: `%s | ${dict["brand"]}` },
    description: dict["meta.description"],
  };
}

export default async function RootLayout({ children }: { children: ReactNode }) {
  const locale = await getLocale();
  const dict = dictionaries[locale];
  return (
    <html lang={locale} dir={locale === "ar" ? "rtl" : "ltr"} className={`${display.variable} ${body.variable}`}>
      <body>
        <I18nProvider locale={locale}>
          <AuthProvider>
            <ToastProvider>
            <a className="skip-link" href="#main">
              {dict["nav.skip"]}
            </a>
            <Header />
            <main id="main">{children}</main>
            <Footer />
            </ToastProvider>
          </AuthProvider>
        </I18nProvider>
      </body>
    </html>
  );
}
