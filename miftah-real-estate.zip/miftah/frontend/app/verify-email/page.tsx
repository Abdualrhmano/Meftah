"use client";

import { Suspense, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { HeroArt } from "@/components/Art";
import { ApiError, api } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n-client";

export default function VerifyEmailPage() {
  return (
    <Suspense fallback={null}>
      <Verify />
    </Suspense>
  );
}

function Verify() {
  const { t } = useI18n();
  const { refresh, user } = useAuth();
  const params = useSearchParams();
  const token = params.get("token") ?? "";
  const [state, setState] = useState<"checking" | "ok" | "error">(token ? "checking" : "error");
  const ran = useRef(false);

  useEffect(() => {
    if (!token || ran.current) return;
    ran.current = true;
    api("/api/auth/verify-email", { method: "POST", json: { token } })
      .then(() => {
        setState("ok");
        if (user) refresh().catch(() => undefined);
      })
      .catch((err) => setState(err instanceof ApiError ? "error" : "error"));
  }, [token, user, refresh]);

  return (
    <div className="container auth-layout">
      <div className="auth-main">
        <h1>{t("auth.verifyTitle")}</h1>
        <div className="auth-form" style={{ textAlign: "center" }}>
          {state === "checking" && <p>{t("auth.verifying")}</p>}
          {state === "ok" && (
            <>
              <p>{t("auth.verifySuccess")}</p>
              <Link href={user ? "/account" : "/login"} className="btn">
                {user ? t("account.title") : t("nav.login")}
              </Link>
            </>
          )}
          {state === "error" && (
            <>
              <p className="error" role="alert">{t("auth.verifyInvalid")}</p>
              <Link href="/account" className="btn ghost">{t("account.title")}</Link>
            </>
          )}
        </div>
      </div>
      <aside className="auth-side" aria-hidden="true">
        <HeroArt />
      </aside>
    </div>
  );
}
