import Link from "next/link";
import { getT } from "@/lib/i18n-server";

export default async function NotFound() {
  const { t } = await getT();
  return (
    <div className="container empty page-empty">
      <h1>{t("detail.notFoundTitle")}</h1>
      <p>{t("detail.notFoundText")}</p>
      <Link href="/properties" className="btn">{t("nav.browse")}</Link>
    </div>
  );
}
