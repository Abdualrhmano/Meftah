import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import ContactOwner from "@/components/ContactOwner";
import Gallery from "@/components/Gallery";
import Icon from "@/components/Icons";
import MapView from "@/components/MapView";
import { serverFetch } from "@/lib/api";
import { amenityLabel, coverOf, formatDate, priceParts } from "@/lib/format";
import { getT } from "@/lib/i18n-server";
import type { Property } from "@/lib/types";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const p = await serverFetch<Property>(`/api/properties/${encodeURIComponent(id)}`);
  if (!p) return {};
  const cover = coverOf(p);
  const description = p.description.slice(0, 160);
  return {
    title: p.title,
    description,
    openGraph: { title: p.title, description, images: cover ? [cover] : undefined },
  };
}

export default async function PropertyPage({ params }: Props) {
  const { id } = await params;
  const p = await serverFetch<Property>(`/api/properties/${encodeURIComponent(id)}`);
  if (!p) notFound();

  const { t, locale } = await getT();
  const price = priceParts(p, t, locale);
  const isRent = p.transaction_type === "rent";
  const kind = p.accommodation_scope === "bed" ? "bed" : p.property_type;

  return (
    <div className="container detail-page">
      <nav className="crumbs" aria-label={t("detail.crumbs")}>
        <ol>
          <li><Link href="/">{t("nav.home")}</Link></li>
          <li><Link href="/properties">{t("nav.browse")}</Link></li>
          <li aria-current="page">{p.city}</li>
        </ol>
      </nav>

      <Gallery media={p.media} kind={kind} title={p.title} />

      <div className="detail">
        <div className="detail-main">
          <header>
            <div className="badges">
              <span className={`tag inline tag-${p.transaction_type}`}>{t(`tx.${p.transaction_type}`)}</span>
              <span className="tag inline tag-plain">{t(`ptype.${p.property_type}`)}</span>
            </div>
            <h1>{p.title}</h1>
            <p className="meta">
              <Icon name="pin" size={16} /> {p.city}
              {p.address ? ` — ${p.address}` : ""}
            </p>
          </header>

          <dl className="facts-list">
            <div><dt>{t("detail.type")}</dt><dd>{t(`ptype.${p.property_type}`)}</dd></div>
            <div><dt>{t("detail.transaction")}</dt><dd>{t(`tx.${p.transaction_type}`)}</dd></div>
            {isRent && p.rental_period && (
              <div><dt>{t("detail.period")}</dt><dd>{t(`period.${p.rental_period}`)}</dd></div>
            )}
            {isRent && (
              <div><dt>{t("detail.scope")}</dt><dd>{t(`scope.${p.accommodation_scope}`)}</dd></div>
            )}
            {p.accommodation_scope === "bed" && p.beds_available && (
              <div><dt>{t("detail.beds")}</dt><dd>{p.beds_available}</dd></div>
            )}
            <div><dt>{t("detail.listedBy")}</dt><dd>{p.owner.name}</dd></div>
            <div><dt>{t("detail.listedOn")}</dt><dd>{formatDate(p.created_at, locale)}</dd></div>
          </dl>

          <section>
            <h2>{t("detail.description")}</h2>
            <p className="prose">{p.description}</p>
          </section>

          {p.amenities.length > 0 && (
            <section>
              <h2>{t("detail.amenities")}</h2>
              <ul className="amenity-list">
                {p.amenities.map((a) => (
                  <li key={a}>
                    <Icon name="check" size={16} /> {amenityLabel(a, t)}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {p.latitude != null && p.longitude != null && (
            <section>
              <h2>{t("detail.location")}</h2>
              <MapView lat={p.latitude} lng={p.longitude} height={320} label={t("detail.location")} />
            </section>
          )}
        </div>

        <aside className="contact" id="contact">
          <p className="price big">
            <strong>{price.amount}</strong>
            {price.unit && <span>{price.unit}</span>}
          </p>
          <ContactOwner property={p} />
        </aside>
      </div>

      <div className="mobile-bar">
        <p className="price">
          <strong>{price.amount}</strong>
          {price.unit && <span>{price.unit}</span>}
        </p>
        <a href="#contact" className="btn">{t("detail.contactBar")}</a>
      </div>
    </div>
  );
}
