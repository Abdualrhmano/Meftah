import { Suspense } from "react";
import PropertyBrowser from "@/components/PropertyBrowser";
import { getT } from "@/lib/i18n-server";

export async function generateMetadata() {
  const { t } = await getT();
  return { title: t("browse.title") };
}

export default async function PropertiesPage() {
  const { t } = await getT();
  return (
    <>
      <div className="container page-head">
        <h1>{t("browse.title")}</h1>
      </div>
      <Suspense fallback={<p className="page-loading container">{t("common.loading")}</p>}>
        <PropertyBrowser />
      </Suspense>
    </>
  );
}
