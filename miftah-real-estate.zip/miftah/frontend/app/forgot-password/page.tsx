"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import AuthShell from "@/components/AuthShell";
import { api } from "@/lib/api";
import { useI18n } from "@/lib/i18n-client";

export default function ForgotPasswordPage() {
  const { t } = useI18n();
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      // The API always answers the same way whether or not the address is
      // registered, so this request can never confirm which emails exist.
      await api("/api/auth/forgot-password", { method: "POST", json: { email } });
    } catch {
      // Fall through to the generic message regardless — see above.
    } finally {
      setBusy(false);
      setSent(true);
    }
  }

  return (
    <AuthShell mode="login">
      <h1>{t("auth.forgotTitle")}</h1>
      {sent ? (
        <div className="auth-form">
          <p>{t("auth.resetSentGeneric")}</p>
          <Link href="/login" className="btn ghost">{t("auth.backToLogin")}</Link>
        </div>
      ) : (
        <>
          <form onSubmit={submit} className="auth-form">
            <p className="hint">{t("auth.forgotHint")}</p>
            <div className="field">
              <label htmlFor="email">{t("auth.email")}</label>
              <input id="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required dir="ltr" />
            </div>
            <button type="submit" className="btn" disabled={busy}>
              {busy ? t("common.loading") : t("auth.forgotSubmit")}
            </button>
          </form>
          <p className="auth-alt">
            <Link href="/login">{t("auth.backToLogin")}</Link>
          </p>
        </>
      )}
    </AuthShell>
  );
}
