"use client";

import { Suspense } from "react";
import Link from "next/link";
import PropertyBrowser from "@/components/PropertyBrowser";
import RequireRole from "@/components/RequireRole";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n-client";

export default function ClientDashboardPage() {
  return (
    <RequireRole role="client">
      <ClientDashboard />
    </RequireRole>
  );
}

function ClientDashboard() {
  const { t } = useI18n();
  const { user } = useAuth();
  return (
    <>
      <div className="container page-head">
        <div>
          <h1>{t("client.hello", { name: user?.name ?? "" })}</h1>
          <p className="lead">{t("client.sub")}</p>
        </div>
        <Link href="/messages" className="btn ghost">{t("nav.messages")}</Link>
      </div>
      <Suspense fallback={<p className="page-loading container">{t("common.loading")}</p>}>
        <PropertyBrowser />
      </Suspense>
    </>
  );
}
