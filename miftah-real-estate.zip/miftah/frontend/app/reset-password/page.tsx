"use client";

import { Suspense, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import AuthShell from "@/components/AuthShell";
import PasswordField from "@/components/PasswordField";
import { ApiError, api } from "@/lib/api";
import { useI18n } from "@/lib/i18n-client";

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={null}>
      <ResetForm />
    </Suspense>
  );
}

function ResetForm() {
  const { t } = useI18n();
  const router = useRouter();
  const params = useSearchParams();
  const token = params.get("token") ?? "";

  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (password !== confirm) {
      setError(t("auth.passwordMismatch"));
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await api("/api/auth/reset-password", { method: "POST", json: { token, new_password: password } });
      setDone(true);
    } catch (err) {
      setError(err instanceof ApiError && err.status === 400 ? t("auth.resetInvalid") : t("err.generic"));
    } finally {
      setBusy(false);
    }
  }

  if (!token) {
    return (
      <AuthShell mode="login">
        <h1>{t("auth.resetTitle")}</h1>
        <p className="error" role="alert">{t("auth.resetInvalid")}</p>
        <Link href="/forgot-password" className="btn">{t("auth.forgotTitle")}</Link>
      </AuthShell>
    );
  }

  if (done) {
    return (
      <AuthShell mode="login">
        <h1>{t("auth.resetTitle")}</h1>
        <p>{t("auth.resetSuccess")}</p>
        <Link href="/login" className="btn">{t("nav.login")}</Link>
      </AuthShell>
    );
  }

  return (
    <AuthShell mode="login">
      <h1>{t("auth.resetTitle")}</h1>
      <form onSubmit={submit} className="auth-form">
        <PasswordField id="password" label={t("auth.newPassword")} value={password} onChange={setPassword} autoComplete="new-password" minLength={8} hint={t("auth.passwordHint")} />
        <PasswordField id="confirm" label={t("auth.confirmPassword")} value={confirm} onChange={setConfirm} autoComplete="new-password" minLength={8} />
        {error && <p className="error" role="alert">{error}</p>}
        <button type="submit" className="btn" disabled={busy}>
          {busy ? t("common.loading") : t("auth.resetSubmit")}
        </button>
      </form>
    </AuthShell>
  );
}
