"use client";

import PropertyForm from "@/components/PropertyForm";
import RequireRole from "@/components/RequireRole";
import { useI18n } from "@/lib/i18n-client";

export default function NewPropertyPage() {
  const { t } = useI18n();
  return (
    <RequireRole role="owner">
      <div className="container form-page">
        <h1>{t("form.newTitle")}</h1>
        <PropertyForm />
      </div>
    </RequireRole>
  );
}
