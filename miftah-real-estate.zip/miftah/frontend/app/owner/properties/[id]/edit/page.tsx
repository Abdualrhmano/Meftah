"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import PropertyForm from "@/components/PropertyForm";
import RequireRole from "@/components/RequireRole";
import { api } from "@/lib/api";
import { useI18n } from "@/lib/i18n-client";
import type { Property } from "@/lib/types";

export default function EditPropertyPage() {
  return (
    <RequireRole role="owner">
      <Editor />
    </RequireRole>
  );
}

function Editor() {
  const { t } = useI18n();
  const { id } = useParams<{ id: string }>();
  const [property, setProperty] = useState<Property | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    api<Property>(`/api/properties/mine/${encodeURIComponent(id)}`)
      .then(setProperty)
      .catch(() => setFailed(true));
  }, [id]);

  return (
    <div className="container form-page">
      <h1>{t("form.editTitle")}</h1>
      {failed && <p className="error" role="alert">{t("err.notFound")}</p>}
      {!failed && !property && <p className="page-loading">{t("common.loading")}</p>}
      {property && <PropertyForm property={property} />}
    </div>
  );
}
