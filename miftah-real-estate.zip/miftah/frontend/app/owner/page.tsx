"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { FacadeArt } from "@/components/Art";
import Icon from "@/components/Icons";
import OwnerRows from "@/components/OwnerRows";
import RequireRole from "@/components/RequireRole";
import { useToast } from "@/components/Toast";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n-client";
import type { Property } from "@/lib/types";

export default function OwnerDashboardPage() {
  return (
    <RequireRole role="owner">
      <OwnerDashboard />
    </RequireRole>
  );
}

function OwnerDashboard() {
  const { t } = useI18n();
  const { user } = useAuth();
  const toast = useToast();
  const [items, setItems] = useState<Property[] | null>(null);
  const [unread, setUnread] = useState(0);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<Property[]>("/api/properties/mine")
      .then(setItems)
      .catch(() => setError(t("err.load")));
    api<{ count: number }>("/api/conversations/unread-count")
      .then((r) => setUnread(r.count))
      .catch(() => undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function toggle(p: Property) {
    try {
      const updated = await api<Property>(`/api/properties/${p.id}/status`, {
        method: "PATCH",
        json: { is_active: !p.is_active },
      });
      setItems((list) => list?.map((x) => (x.id === p.id ? updated : x)) ?? null);
      toast.show(updated.is_active ? t("toast.shown") : t("toast.hidden"));
    } catch {
      toast.show(t("err.generic"), "error");
    }
  }

  async function remove(p: Property) {
    if (!window.confirm(t("owner.confirmDelete", { title: p.title }))) return;
    try {
      await api(`/api/properties/${p.id}`, { method: "DELETE" });
      setItems((list) => list?.filter((x) => x.id !== p.id) ?? null);
      toast.show(t("toast.deleted"));
    } catch {
      toast.show(t("err.generic"), "error");
    }
  }

  const total = items?.length ?? 0;
  const active = items?.filter((p) => p.is_active).length ?? 0;
  const forSale = items?.filter((p) => p.transaction_type === "sale").length ?? 0;
  const forRent = total - forSale;

  return (
    <div className="container owner-page">
      <div className="page-head">
        <div>
          <h1>{t("owner.hello", { name: user?.name ?? "" })}</h1>
          <p className="lead">{t("owner.sub")}</p>
        </div>
        <Link href="/owner/properties/new" className="btn">
          <Icon name="plus" /> {t("nav.addProperty")}
        </Link>
      </div>

      {error && <p className="error" role="alert">{error}</p>}
      {items === null && !error && <p className="page-loading">{t("common.loading")}</p>}

      {items && items.length === 0 && (
        <div className="empty-listings">
          <div className="empty-art">
            <FacadeArt kind="apartment" />
          </div>
          <div>
            <h2>{t("owner.checklist.title")}</h2>
            <ol className="steps">
              <li>{t("owner.checklist.1")}</li>
              <li>{t("owner.checklist.2")}</li>
              <li>{t("owner.checklist.3")}</li>
            </ol>
            <Link href="/owner/properties/new" className="btn">
              <Icon name="plus" /> {t("nav.addProperty")}
            </Link>
          </div>
        </div>
      )}

      {items && items.length > 0 && (
        <>
          <dl className="stats">
            <div><dt>{t("owner.stats.total")}</dt><dd>{total}</dd></div>
            <div><dt>{t("owner.stats.active")}</dt><dd>{active}</dd></div>
            <div><dt>{t("owner.stats.sale")}</dt><dd>{forSale}</dd></div>
            <div><dt>{t("owner.stats.rent")}</dt><dd>{forRent}</dd></div>
            <div>
              <dt>{t("owner.stats.unread")}</dt>
              <dd>
                <Link href="/messages">{unread}</Link>
              </dd>
            </div>
          </dl>
          <OwnerRows items={items} onToggle={toggle} onDelete={remove} />
        </>
      )}
    </div>
  );
}
