"use client";

import { Suspense, useCallback, useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import Icon from "@/components/Icons";
import MessageList from "@/components/MessageList";
import RequireRole from "@/components/RequireRole";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatTime } from "@/lib/format";
import { useI18n } from "@/lib/i18n-client";
import type { Conversation, Message } from "@/lib/types";

export default function MessagesPage() {
  return (
    <RequireRole>
      <Suspense fallback={null}>
        <Inbox />
      </Suspense>
    </RequireRole>
  );
}

function Inbox() {
  const { t, locale } = useI18n();
  const { user } = useAuth();
  const router = useRouter();
  const params = useSearchParams();
  const selected = Number(params.get("c")) || null;
  const [conversations, setConversations] = useState<Conversation[] | null>(null);

  const load = useCallback(async () => {
    try {
      setConversations(await api<Conversation[]>("/api/conversations"));
    } catch {
      /* keep the previous list on transient errors */
    }
  }, []);

  useEffect(() => {
    load();
    const timer = setInterval(load, 8000);
    return () => clearInterval(timer);
  }, [load]);

  const current = conversations?.find((c) => c.id === selected) ?? null;

  return (
    <div className="container messages-page">
      <h1>{t("nav.messages")}</h1>
      <div className={`msgs${selected ? " has-thread" : ""}`}>
        <div className="msgs-list">
          {conversations === null && <p className="page-loading">{t("common.loading")}</p>}
          {conversations && conversations.length === 0 && (
            <div className="empty small">
              <p>{t("msgs.empty")}</p>
              {user?.role === "client" && <Link href="/properties" className="btn ghost sm">{t("nav.browse")}</Link>}
            </div>
          )}
          <ul>
            {conversations?.map((c) => (
              <li key={c.id}>
                <button
                  type="button"
                  className={c.id === selected ? "active" : undefined}
                  onClick={() => router.replace(`/messages?c=${c.id}`, { scroll: false })}
                >
                  <span className="conv-top">
                    <strong>{c.other_user.name}</strong>
                    {c.unread_count > 0 && <span className="badge">{c.unread_count}</span>}
                  </span>
                  <span className="conv-property">{c.property.title}</span>
                  {c.last_message && (
                    <span className="conv-last">
                      {c.last_message.body}
                      <time dateTime={c.last_message.created_at}> {formatTime(c.last_message.created_at, locale)}</time>
                    </span>
                  )}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="msgs-thread">
          {selected && user ? (
            <Thread key={selected} id={selected} me={user.id} conversation={current} onBack={() => router.replace("/messages")} onRead={load} />
          ) : (
            <p className="empty-thread">{t("msgs.pick")}</p>
          )}
        </div>
      </div>
    </div>
  );
}

function Thread({
  id,
  me,
  conversation,
  onBack,
  onRead,
}: {
  id: number;
  me: number;
  conversation: Conversation | null;
  onBack: () => void;
  onRead: () => void;
}) {
  const { t } = useI18n();
  const [messages, setMessages] = useState<Message[]>([]);
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [failed, setFailed] = useState(false);
  const lastId = useRef(0);
  const scroller = useRef<HTMLDivElement>(null);

  const merge = useCallback((incoming: Message[]) => {
    setMessages((prev) => {
      const seen = new Set(prev.map((m) => m.id));
      const fresh = incoming.filter((m) => !seen.has(m.id));
      return fresh.length ? [...prev, ...fresh].sort((a, b) => a.id - b.id) : prev;
    });
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function poll() {
      try {
        const fresh = await api<Message[]>(`/api/conversations/${id}/messages?after_id=${lastId.current}`);
        if (cancelled || fresh.length === 0) return;
        lastId.current = Math.max(lastId.current, fresh[fresh.length - 1].id);
        merge(fresh);
        onRead();
      } catch {
        /* retry on the next tick */
      }
    }
    poll();
    const timer = setInterval(poll, 5000);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [id, merge, onRead]);

  useEffect(() => {
    if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [messages.length]);

  async function send(e: FormEvent | KeyboardEvent<HTMLTextAreaElement>) {
    e.preventDefault();
    const text = body.trim();
    if (!text || sending) return;
    setSending(true);
    setFailed(false);
    try {
      const message = await api<Message>(`/api/conversations/${id}/messages`, { method: "POST", json: { body: text } });
      merge([message]);
      setBody("");
      onRead();
    } catch {
      setFailed(true);
    } finally {
      setSending(false);
    }
  }

  return (
    <>
      <header className="thread-head">
        <button type="button" className="thread-back" onClick={onBack} aria-label={t("msgs.back")}>
          <Icon name="chevron" size={20} />
        </button>
        {conversation ? (
          <div>
            <strong>{conversation.other_user.name}</strong>
            <Link href={`/properties/${conversation.property.id}`}>{conversation.property.title}</Link>
          </div>
        ) : (
          <strong>{t("common.loading")}</strong>
        )}
      </header>

      <div className="thread-body" ref={scroller}>
        <MessageList messages={messages} me={me} />
      </div>

      <form className="composer" onSubmit={send}>
        <label htmlFor="composer-body" className="sr-only">{t("msgs.write")}</label>
        <textarea
          id="composer-body"
          rows={2}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          maxLength={4000}
          placeholder={t("msgs.write")}
          onKeyDown={(e) => {
            if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) send(e);
          }}
        />
        <button type="submit" className="btn" disabled={sending || !body.trim()}>
          <Icon name="send" size={16} /> {t("msgs.send")}
        </button>
        <p className="hint composer-hint">{t("msgs.hint")}</p>
        {failed && <p className="error" role="alert">{t("err.generic")}</p>}
      </form>
    </>
  );
}
