import Link from "next/link";
import { FacadeArt, HeroArt } from "@/components/Art";
import HeroSearch from "@/components/HeroSearch";
import { PropertyGrid } from "@/components/PropertyCard";
import { serverFetch } from "@/lib/api";
import { getT } from "@/lib/i18n-server";
import type { PropertyList } from "@/lib/types";

const CATEGORIES = [
  { key: "apartment", href: "/properties?property_type=apartment", art: "apartment" },
  { key: "building", href: "/properties?property_type=building", art: "building" },
  { key: "land", href: "/properties?property_type=land", art: "land" },
  { key: "bed", href: "/properties?transaction_type=rent&scope=bed", art: "bed" },
] as const;

export default async function HomePage() {
  const { t } = await getT();
  const latest = await serverFetch<PropertyList>("/api/properties?page_size=8");
  const items = latest?.items ?? [];

  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-copy">
            <h1>{t("hero.title")}</h1>
            <p className="lead">{t("hero.sub")}</p>
            <HeroSearch />
          </div>
          <div className="hero-figure">
            <HeroArt />
            <span className="hero-tag">{t("hero.tag")}</span>
          </div>
        </div>
      </section>

      <section className="section container">
        <h2>{t("home.browseBy")}</h2>
        <ul className="categories">
          {CATEGORIES.map((c) => (
            <li key={c.key}>
              <Link href={c.href} className="category">
                <span className="category-art">
                  <FacadeArt kind={c.art} />
                </span>
                <span className="category-text">
                  <strong>{t(`cat.${c.key}`)}</strong>
                  <span>{t(`cat.${c.key}.text`)}</span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section className="section container">
        {items.length > 0 ? (
          <>
            <div className="section-head">
              <h2>{t("home.latest")}</h2>
              <Link href="/properties" className="btn ghost sm">{t("home.viewAll")}</Link>
            </div>
            <PropertyGrid items={items} />
          </>
        ) : (
          <div className="empty-listings">
            <div className="empty-art">
              <FacadeArt kind="apartment" />
            </div>
            <div>
              <h2>{t("home.empty.title")}</h2>
              <p>{t("home.empty.text")}</p>
              <Link href="/register?role=owner" className="btn">{t("home.empty.cta")}</Link>
            </div>
          </div>
        )}
      </section>

      <section className="section container">
        <h2>{t("how.title")}</h2>
        <div className="split">
          <div className="panel">
            <h3>{t("how.clients.title")}</h3>
            <ol className="steps">
              <li>{t("how.clients.1")}</li>
              <li>{t("how.clients.2")}</li>
              <li>{t("how.clients.3")}</li>
            </ol>
            <Link href="/properties" className="btn">{t("how.clients.cta")}</Link>
          </div>
          <div className="panel dark">
            <h3>{t("how.owners.title")}</h3>
            <ol className="steps">
              <li>{t("how.owners.1")}</li>
              <li>{t("how.owners.2")}</li>
              <li>{t("how.owners.3")}</li>
            </ol>
            <Link href="/register?role=owner" className="btn light">{t("how.owners.cta")}</Link>
          </div>
        </div>
      </section>
    </>
  );
}
