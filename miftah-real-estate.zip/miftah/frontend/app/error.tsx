"use client";

import { useI18n } from "@/lib/i18n-client";

export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const { t } = useI18n();
  return (
    <div className="container empty page-empty" role="alert">
      <h1>{t("err.title")}</h1>
      <p>{t("err.generic")}</p>
      <button type="button" className="btn" onClick={reset}>{t("err.retry")}</button>
    </div>
  );
}
